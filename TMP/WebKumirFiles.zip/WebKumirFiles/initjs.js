var fs = require("fs");
const http = require('http');

var reconect_count=5*24*60*60/5; //reconects on 5 day

console.log('Getting the server port  |  Получение порта сервера');

var servers,GameLogin, GamePassword;
try {
	var server_data_file=fs.readFileSync("port.txt", "utf8").trim().split('\n');
	servers = server_data_file[0].trim().split(';;');
	GameLogin = server_data_file[1].trim();
	GamePassword = server_data_file[2].trim();
}catch (e) {error_console(e);while(1){}}

console.log('Server ip: ['+servers.join(', ')+']');
console.log('Admin login: '+GameLogin);
console.log('Admin password: '+GamePassword);
console.log('');



console.log('Getting kumir.js |  Получение kumir.js');
try {
	eval(fs.readFileSync('index\\js\\kumir.js', "utf8"));
}catch (e) {error_console(e);while(1){}}
if (!RunKumir_try){error_console('function RunKumir_try not defined |  Функция RunKumir_try не определена');while(1){}}
RunKumir_try('');
if (ErrorKumir.length<1){error_console('function RunKumir_try not correctly working |  Функция RunKumir_try не верно работает');while(1){}}
console.log('\x1b[32m%s\x1b[0m','OK');
console.log('');


var MD5=function(r){function i(r,n){return r<<n|r>>>32-n}
function c(r,n){var t,o,e,u,a;return e=2147483648&r,u=2147483648&n,a=(1073741823&r)+(1073741823&n),(t=1073741824&r)&(o=1073741824&n)?2147483648^a^e^u:t|o?1073741824&a?3221225472^a^e^u:1073741824^a^e^u:a^e^u}
function n(r,n,t,o,e,u,a){var f;return r=c(r,c(c((f=n)&t|~f&o,e),a)),c(i(r,u),n)}
function t(r,n,t,o,e,u,a){var f;return r=c(r,c(c(n&(f=o)|t&~f,e),a)),c(i(r,u),n)}
function o(r,n,t,o,e,u,a){return r=c(r,c(c(n^t^o,e),a)),c(i(r,u),n)}
function e(r,n,t,o,e,u,a){return r=c(r,c(c(t^(n|~o),e),a)),c(i(r,u),n)}
function u(r){var n,t="",o="";for(n=0;n<=3;n++)
t+=(o="0"+(r>>>8*n&255).toString(16)).substr(o.length-2,2);return t}
var a,f,C,g,h,v,d,S,l,m=Array();for(m=function(r){for(var n,t=r.length,o=t+8,e=16*(1+(o-o%64)/64),u=Array(e-1),a=0,f=0;f<t;)
a=f%4*8,u[n=(f-f%4)/4]=u[n]|r.charCodeAt(f)<<a,f++;return a=f%4*8,u[n=(f-f%4)/4]=u[n]|128<<a,u[e-2]=t<<3,u[e-1]=t>>>29,u}
(r=function(r){r=r.replace(/\r\n/g,"\n");for(var n="",t=0;t<r.length;t++){var o=r.charCodeAt(t);o<128?n+=String.fromCharCode(o):(127<o&&o<2048?n+=String.fromCharCode(o>>6|192):(n+=String.fromCharCode(o>>12|224),n+=String.fromCharCode(o>>6&63|128)),n+=String.fromCharCode(63&o|128))}
return n}
(r)),v=1732584193,d=4023233417,S=2562383102,l=271733878,a=0;a<m.length;a+=16)
v=n(f=v,C=d,g=S,h=l,m[a+0],7,3614090360),l=n(l,v,d,S,m[a+1],12,3905402710),S=n(S,l,v,d,m[a+2],17,606105819),d=n(d,S,l,v,m[a+3],22,3250441966),v=n(v,d,S,l,m[a+4],7,4118548399),l=n(l,v,d,S,m[a+5],12,1200080426),S=n(S,l,v,d,m[a+6],17,2821735955),d=n(d,S,l,v,m[a+7],22,4249261313),v=n(v,d,S,l,m[a+8],7,1770035416),l=n(l,v,d,S,m[a+9],12,2336552879),S=n(S,l,v,d,m[a+10],17,4294925233),d=n(d,S,l,v,m[a+11],22,2304563134),v=n(v,d,S,l,m[a+12],7,1804603682),l=n(l,v,d,S,m[a+13],12,4254626195),S=n(S,l,v,d,m[a+14],17,2792965006),v=t(v,d=n(d,S,l,v,m[a+15],22,1236535329),S,l,m[a+1],5,4129170786),l=t(l,v,d,S,m[a+6],9,3225465664),S=t(S,l,v,d,m[a+11],14,643717713),d=t(d,S,l,v,m[a+0],20,3921069994),v=t(v,d,S,l,m[a+5],5,3593408605),l=t(l,v,d,S,m[a+10],9,38016083),S=t(S,l,v,d,m[a+15],14,3634488961),d=t(d,S,l,v,m[a+4],20,3889429448),v=t(v,d,S,l,m[a+9],5,568446438),l=t(l,v,d,S,m[a+14],9,3275163606),S=t(S,l,v,d,m[a+3],14,4107603335),d=t(d,S,l,v,m[a+8],20,1163531501),v=t(v,d,S,l,m[a+13],5,2850285829),l=t(l,v,d,S,m[a+2],9,4243563512),S=t(S,l,v,d,m[a+7],14,1735328473),v=o(v,d=t(d,S,l,v,m[a+12],20,2368359562),S,l,m[a+5],4,4294588738),l=o(l,v,d,S,m[a+8],11,2272392833),S=o(S,l,v,d,m[a+11],16,1839030562),d=o(d,S,l,v,m[a+14],23,4259657740),v=o(v,d,S,l,m[a+1],4,2763975236),l=o(l,v,d,S,m[a+4],11,1272893353),S=o(S,l,v,d,m[a+7],16,4139469664),d=o(d,S,l,v,m[a+10],23,3200236656),v=o(v,d,S,l,m[a+13],4,681279174),l=o(l,v,d,S,m[a+0],11,3936430074),S=o(S,l,v,d,m[a+3],16,3572445317),d=o(d,S,l,v,m[a+6],23,76029189),v=o(v,d,S,l,m[a+9],4,3654602809),l=o(l,v,d,S,m[a+12],11,3873151461),S=o(S,l,v,d,m[a+15],16,530742520),v=e(v,d=o(d,S,l,v,m[a+2],23,3299628645),S,l,m[a+0],6,4096336452),l=e(l,v,d,S,m[a+7],10,1126891415),S=e(S,l,v,d,m[a+14],15,2878612391),d=e(d,S,l,v,m[a+5],21,4237533241),v=e(v,d,S,l,m[a+12],6,1700485571),l=e(l,v,d,S,m[a+3],10,2399980690),S=e(S,l,v,d,m[a+10],15,4293915773),d=e(d,S,l,v,m[a+1],21,2240044497),v=e(v,d,S,l,m[a+8],6,1873313359),l=e(l,v,d,S,m[a+15],10,4264355552),S=e(S,l,v,d,m[a+6],15,2734768916),d=e(d,S,l,v,m[a+13],21,1309151649),v=e(v,d,S,l,m[a+4],6,4149444226),l=e(l,v,d,S,m[a+11],10,3174756917),S=e(S,l,v,d,m[a+2],15,718787259),d=e(d,S,l,v,m[a+9],21,3951481745),v=c(v,f),d=c(d,C),S=c(S,g),l=c(l,h);return(u(v)+u(d)+u(S)+u(l)).toLowerCase()};var RegistrationHash=function(h,p){return MD5('Hash:'+h+';Password:'+p+';');};

var cache_file={};
function cache_read_file(file_s)
{
	if (cache_file[file_s]==undefined)
	try
	{
		cache_file[file_s]=fs.readFileSync(file_s, "utf8");
	}catch (e) {error_console(e)}
	return cache_file[file_s];
}
function GetStringDate()
{
	return (new Date()).toLocaleString("ru", {year: 'numeric', month: '2-digit', day: 'numeric', timezone: 'UTC', hour: 'numeric', minute: 'numeric', second: 'numeric'});
}

var error_console_count=10;
function error_console(s,i)
{
	if (i==undefined)
	{
		console.log('\x1b[31m%s\x1b[0m',s);
		error_console_count--;
		if (error_console_count<1)
			return;
		fs.appendFileSync('nodejs_errors.txt', '\r\n'+GetStringDate()+':'+s);
		if (error_console_count>=9)
			setTimeout(()=>{error_console(s,10)},1000);
		return;
	}
	if (i>0)
	{
		console.log('Закрытие консоли через '+i+' секунд');
		setTimeout(()=>{error_console(s,i-1)},1000);
		return;
	}
	process.exit();
}
function http_get(url,callback,error_callback,p1,p2,p3,p4)
{
	try
	{
		var tmp={
			hostname: GetIn(url,'//','/').split(':')[0],
			port:  ~~(GetIn(url,'//','/').split(':')[1]||'80'),
			path: '/'+GetIn(GetIn(url,'//',''),'/',''),
			method: 'GET',
			headers: {},
			timeout: 5000
		};
		var req=http.request(tmp, (res) => {
			//console.log('te',res);
			//while (true){}
			if (res.statusCode !== 200) {
				error_callback('res.statusCode == '+res.statusCode,p1,p2,p3,p4);
				res.resume();
				return;
			 }
			res.setEncoding('utf8');
			var rawData = '';
			res.on('data', (chunk) => {rawData+=chunk});
			res.on('end', () => {callback(rawData,p1,p2,p3,p4)});
		}).on('error', (e) => {error_callback(e,p1,p2,p3,p4)});
		req.on('error', (e) => {
		  error_callback(e,p1,p2,p3,p4);
		});
		req.on('timeout', () => {
			error_callback('timeout',p1,p2,p3,p4);
			req.destroy();
		});
		req.end();
	}catch (e) {error_callback(e,p1,p2,p3,p4)}
}
function http_post(url,postData,callback,error_callback,p1,p2,p3,p4)//http_post('localhost:80','kekkek',console.log,console.log);
{
	try
	{
		var tmp={
			hostname: GetIn(url,'//','/').split(':')[0],
			port:  ~~(GetIn(url,'//','/').split(':')[1]||'80'),
			path: '/'+GetIn(GetIn(url,'//',''),'/',''),
			method: 'POST',
			headers: {
				'Content-Type': 'application/json',
				'Content-Length': Buffer.byteLength(postData),
			},
			timeout: 5000
		};
		var req=http.request(tmp, (res) => {
			//console.log('te',res);
			//while (true){}
			if (res.statusCode !== 200) {
				error_callback('res.statusCode == '+res.statusCode,p1,p2,p3,p4);
				res.resume();
				return;
			 }
			res.setEncoding('utf8');
			var rawData = '';
			res.on('data', (chunk) => {rawData+=chunk});
			res.on('end', () => {callback(rawData,p1,p2,p3,p4)});
		}).on('error', (e) => {error_callback(e,p1,p2,p3,p4)});
		req.on('error', (e) => {
		  error_callback(e,p1,p2,p3,p4);
		});
		req.on('timeout', () => {
			error_callback('timeout',p1,p2,p3,p4);
			req.destroy();
		});
		req.write(postData);
		req.end();
	}catch (e) {error_callback(e,p1,p2,p3,p4)}
}
var best_server='';
var Serv_iswork=false;
var get_errors=0;
var Serv_SendProgramm_reconect_counter=reconect_count;
function Serv_SendProgramm(Progr /*string*/, Task, callback, error_callback, leng, progress, p1, p2, p3, p4)
{
	if (leng == undefined) {
		leng = 'kumir';
	}
	if (progress == undefined) {
		progress = '';
	}

	if (GameLogin != '') {
		if (Serv_iswork == true) {
			setTimeout(()=>{
				Serv_SendProgramm(Progr /*string*/, Task, callback, error_callback, leng, progress, p1, p2, p3, p4);
			}, 1);
			return;
		}
		Serv_iswork = true;
		http_get(best_server+'commands/' + GameLogin + '/upload;' + leng + ';' + Task + ';' + progress + ';.txt',
			(s)=>{
				Serv_SendProgramm_reconect_counter=reconect_count;
				http_post(best_server+'__/protect/' + RegistrationHash(s, GamePassword) + '.txt',encodeURIComponent(Progr).replace(/%20/g, "+"),
				(s)=>{
					Serv_SendProgramm_reconect_counter=reconect_count;
					Serv_iswork = false;
					if ('__PrOtEcT_NoT_CoMpLeTeD__' != s) {
						get_errors = 0;
						callback(s,p1,p2,p3,p4);
					} else {
						get_errors++;
						if (get_errors > 10)
						{
							error_callback('Неверный логин или пароль (связь с сервером потеряна)'+e,p1,p2,p3,p4);
							return;
						}
						Serv_SendProgramm(Progr /*string*/, Task, callback, error_callback, leng, progress, p1, p2, p3, p4);
					}
					
				},(e)=>{
					if (Serv_SendProgramm_reconect_counter-- > 0)
						Serv_iswork=false,setTimeout(()=>{
							Serv_SendProgramm(Progr /*string*/, Task, callback, error_callback, leng, progress, p1, p2, p3, p4);
						}, 5000),console.log('reconect...');
					else
						error_callback('Сервер не ответил(2.2): '+e,p1,p2,p3,p4);
				});
			},(e)=>{
				if (Serv_SendProgramm_reconect_counter-- > 0)
					Serv_iswork=false,setTimeout(()=>{
						Serv_SendProgramm(Progr /*string*/, Task, callback, error_callback, leng, progress, p1, p2, p3, p4);
					}, 5000),console.log('reconect...');
				else
					error_callback('Сервер не ответил(2.1): '+e,p1,p2,p3,p4);
			});
	} else 
		error_callback('Пользователь не залогинен.',p1,p2,p3,p4);
}

var Serv_Command_reconect_counter=reconect_count;
function Serv_Command(req,callback,error_callback,p1,p2,p3,p4)
{
	if (GameLogin != '') {
		if (Serv_iswork) {
			setTimeout(()=>{
				Serv_Command(req,callback,error_callback,p1,p2,p3,p4)
			}, 1);
			return;
		}
		Serv_iswork = true;
		http_get(best_server+'commands/' + GameLogin + '/' +  encodeURIComponent(req).replace(/%20/g, "+")+ '.txt',
			(s)=>{
				Serv_Command_reconect_counter=reconect_count;
				http_get(best_server+'_'+''+'_/protect/' + RegistrationHash(s, GamePassword) + '.txt',
					(s)=>{
						Serv_Command_reconect_counter=reconect_count;
						Serv_iswork = false;
						if ('___NoT_FoUnD_CoMmAnD__'+encodeURIComponent(req).replace(/%20/g, "+")+'___NoT_FoUnD_CoMmAnD__' == s) {
							error_callback('Неверный логин или пароль (связь с сервером потеряна)',p1,p2,p3,p4);
							return;
						}
						if ('__PrOtEcT_NoT_CoMpLeTeD__' != s) {
							get_errors = 0;
							callback(s,p1,p2,p3,p4);
						} else {
							get_errors++;
							if (get_errors > 10) {
								error_callback('Неверный логин или пароль (связь с сервером потеряна)',p1,p2,p3,p4);
								return;
							}
							Serv_Command(req,callback,error_callback,p1,p2,p3,p4);
						}
					},(e)=>{
						if (Serv_Command_reconect_counter-- > 0)
							Serv_iswork=false,setTimeout(()=>{
								Serv_Command(req,callback,error_callback,p1,p2,p3,p4);
							}, 5000),console.log('reconect...');
						else
							error_callback('Сервер не ответил(1.2): '+e,p1,p2,p3,p4);
					});
			},(e)=>{
				if (Serv_Command_reconect_counter-- > 0)
					Serv_iswork=false,setTimeout(()=>{
						Serv_Command(req,callback,error_callback,p1,p2,p3,p4)
					}, 5000),console.log('reconect...');
				else
					error_callback('Сервер не ответил(1.1): '+e,p1,p2,p3,p4)
			});
	} else 
		error_callback('Пользователь не залогинен.',p1,p2,p3,p4);
}

console.log('Connecting to server |  Подключение к серверу');
var server_data='';
var serv_ind=-1;
try
{
	for (var i=0;i<servers.length;i++)
	{
		url='http://' + servers[i] + '/_can_i_register_.txt?' + i;
		http_get(url,(s,ii)=>{
			if(s=='YES'||s=='NO')
			{
				if (serv_ind==-1)serv_ind=ii;
				if (ii<serv_ind)serv_ind=ii;
				best_server='http://' + servers[serv_ind] + '/';
			}
		},()=>{},i);
	}
}catch (e) {error_console(e);}
console.log('\x1b[32m%s\x1b[0m','OK');
console.log('');

//Serv_Command('GetTests', ParseData, 4);



console.log('Server connection... | Подключение к серверу...');
var TM_downloading=300;
function downloading()
{
	if (TM_downloading<0){
		error_console('Не удалось подключиться к серверу');
		return;
	}
	if (best_server==''){
		TM_downloading--;
		setTimeout(downloading,10);
		return;
	}
	if (server_data==''){
		server_data=' ';
		console.log('Requesting information about projects | Запрос информации о проектах');
		Serv_Command('GetTests', (s)=>{server_data=JSON.parse(s);downloading();}, error_console);
		//setTimeout(downloading,200);
		return;
	}
	if (server_data==' '){
		console.log('waiting for the file | ждём файл');
		setTimeout(downloading,200);
		return;
	}
	Serv_Command('GetPrograms',(s)=>{console.log('\x1b[32m%s\x1b[0m','Testing system launched | Тестирующая система запущена');console.log();RunTesting(s)},error_console);
}
setTimeout(downloading,10);
var testing_programing_cash={};
var last_testing=(new Date())-30*60*1000;
function RunTesting(s)
{
	var tmp=s.split(';');
	for (var i=0;i<tmp.length;i++)
		if (tmp[i].trim()!='')
		{
			last_testing=new Date();
			if (testing_programing_cash[tmp[i]]==undefined)
			{
				Serv_Command('GetProgram' + tmp[i],(s2,s3,ii)=>{testing_programing_cash[ii]=s2;RunTesting(s3);},error_console,s,tmp[i]);
				return;
			}
			var ss=testing_programing_cash[tmp[i]];
			var prog_num=parseInt(tmp[i]);
			var proj_num=parseInt(ss.split('\n')[0].trim());
			var proj_task=GetIn(ss, "\n", "").split('\n')[0].trim();
			var programm=GetIn(GetIn(ss, "\n", ""), "\n", "");
			var cnt=0;
			var error_cnt=0;
			var out_text='';
			for (var k in server_data[proj_num][proj_task])
			{
				RunKumir_try(programm, cache_read_file(server_data[proj_num][proj_task][k]));
				cnt++;
				if (ErrorKumir.length > 0) {
					error_cnt++;
					out_text += 'error in test №'+cnt+':\n';
					out_text += JSON.stringify(ErrorKumir, null, '  ')+'\n';
					out_text += '\n';
				}
			}
			var ball=1234;
			if (cnt != 0)
				ball = Math.round((cnt - error_cnt) / (cnt) * 100);
			out_text=out_text.trim()+' '+'\nresult:'+ball+'\n';
			if (error_cnt==0)out_text='';
			Serv_SendProgramm(out_text.trim(), prog_num, ()=>{
				console.log('\x1b[2m\x1b[33m%s\x1b[0m',GetStringDate()+':');
				console.log('\x1b[2m\x1b[33m%s\x1b[0m','Program №'+Math.floor(prog_num / 10000000)+'_'+(prog_num % 10000000)+' on task "'+proj_task+'"(proj:'+proj_num+') tested | Программа №'+Math.floor(prog_num / 10000000)+'_'+(prog_num % 10000000)+' на задаче "'+proj_task+'"(проект:'+proj_num+') проверена ');
				console.log();
				Serv_Command('GetPrograms',RunTesting,error_console);
			}, error_console, 'res', ball);
			return;
		}
	var interv=500;
	if ((new Date())-last_testing>30*1000) // 30 second
		interv=1000;
	if ((new Date())-last_testing>60*1000) // minute
		interv=2000;
	if ((new Date())-last_testing>5*60*1000) // 5 minutes
		interv=3000;
	if ((new Date())-last_testing>10*60*1000) // 10 minutes
		interv=4000;
	if ((new Date())-last_testing>30*60*1000) // 30 minutes
		interv=5000;
	if ((new Date())-last_testing>30*60*1000) // hour
		interv=10000;
	setTimeout(()=>{Serv_Command('GetPrograms',RunTesting,error_console)},interv);
}
'';