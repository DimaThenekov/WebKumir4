function SaveVal(a, b) {
	localStorage.setItem(a, b);
}
function GetVal(a, b) {
	if (null != sessionStorage.getItem(a))
		return sessionStorage.getItem(a);
	else
		return b;
}
function StrToMap(s)
{

	var map = [];
	var smapline = s.split('\n')[1];
	mapsizeX = parseInt(s.split('\n')[1].split(' ')[0]);
	mapsizeY = parseInt(s.split('\n')[1].split(' ')[1]);
	if (map.length != mapsizeX + 2) {
		map = new Array(mapsizeX + 2);
	}
	for (var i = 0; i < map.length; i++)
		if (map[i] == undefined || map[i].length != mapsizeY + 2) {
			map[i] = new Array(mapsizeY + 2);
		}
	for (var i = 0; i < map.length; i++) {
		for (var j = 0; j < map[i].length; j++) {
			if (map[i][j] == undefined || map[i][j].length != 7) {
				map[i][j] = new Array(7);
			}
			map[i][j][0] = 0; //Wall
			map[i][j][1] = 0; //Color
			map[i][j][2] = 0; //Radiation
			map[i][j][3] = 0; //Temperature
			map[i][j][4] = "$"; //Symbol
			map[i][j][5] = "$"; //Symbol1
			map[i][j][6] = ""; //Point
		}
	}
	for (var i = 0; i < mapsizeX + 1; i++) {
		for (var j = 0; j < mapsizeY + 1; j++) {
			map[i][j][0] = 0; //Wall
			map[i][j][1] = 0; //Color
			map[i][j][2] = 0; //Radiation
			map[i][j][3] = 0; //Temperature
			map[i][j][4] = "$"; //Symbol
			map[i][j][5] = "$"; //Symbol1
			map[i][j][6] = ""; //Point
		}
	}
	
	var j = 5;
	var split_text=s.split('\n');
	while (j < split_text.length) {
		//document.getElementById('area').value
		smapline = split_text[j].split(' ');
		if (split_text[j]=='')
			break;
		if (['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '.'].indexOf(split_text[j][0]) == -1)
			break;
		if (smapline.length > 2) {
			map[smapline[0]][smapline[1]][0] = parseInt(smapline[2]); //Wall
			map[smapline[0]][smapline[1]][1] = parseFloat(smapline[3]); //Color
			map[smapline[0]][smapline[1]][2] = parseFloat(smapline[4]); //Radiation
			map[smapline[0]][smapline[1]][3] = parseFloat(smapline[5]); //Temperature
			map[smapline[0]][smapline[1]][4] = smapline[6].trim(); //Symbol
			map[smapline[0]][smapline[1]][5] = smapline[7].trim(); //Symbol1
			map[smapline[0]][smapline[1]][6] = smapline[8].trim(); //Point
		}
		j++;
	}
	return map;
}
function Render(_canvas, map) {
	var _ctx = _canvas.getContext("2d");
	if (_canvas.height != 320) {
		_canvas.height = 320;
		_canvas.width = 320;
	}
	if (_canvas.width != 320) {
		_canvas.height = 320;
		_canvas.width = 320;
	}
	_ctx.fillStyle = "green";
	_ctx.fillRect(0, 0, _canvas.width, _canvas.height);
	var mapsizeX=map.length-2;
	var mapsizeY=map[0].length-2;
	var mapX=Math.floor(320/2);
	var mapY=Math.floor(320/2);
	var mapZ=320/200;
	var max = 200 / Math.max(mapsizeX + 2, mapsizeY + 2);
	DrawMyRect(-max * ((mapsizeX + 2) / 2), -max * ((mapsizeY + 2) / 2), max * ((mapsizeX + 2) / 2), max * ((mapsizeY + 2) / 2), "green",_ctx)

	var mysize1 = 100;
	var mysize2 = 20;

	var i2 = -1,
	j2 = -1;
	var image = new Image();
	image.src = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAACNUSURBVHhe7Z0PnM1lvscZzBjDzPgz/o0ZDIaGCeUWKwlRLEWpVNpCyS2tTS2xV3t1060oKrvJFS3Fhuwqliz9QZoihbDcbO1qdZUoQop+93x+RqZ5vuec5znP+fM753zer9f79exmzr/nPM/vPL/nz/dbgRBCCCGEEEIIIYQQQgghhBBCCCGEEEJIHPLAAw84RUVFTqVKlZzU1FSnQ4cOzpNPPumU/jMhJBFZtmwZOnlAd+/ejZIQkkisWLFC6ez+/PTTT1ESQhIIpaMHkRCSCPTt21fq4AF9+OGHURJC4pm9e/cqndtAQkg8U69ePaljazlgwACUhJB4ZPHixUqnNnXfvn0oCSFxiNKhTc3NzUVJCIkn7r33XqUzh+rSpUtREkLiCKUjW0oIiQe6dOkidWArx48fj5IQ4mW2b9+udN4wSgjxMtWrV5c6bljs3r07SkKIF3n22WeVThtud+3ahZIQ4kGUDhtus7OzURJCvMTw4cOVzhop582bh5IQ4gWOHTumdNIoSAjxAm3btpU6aES98847URJCYsmGDRuUzhktT5w4gZIQEitSUlKUjqlrtaqhPxYilqCvJITEgqlTpyqd0sSXHs9zfjW4tvhvum7cuBElISQGKB1S15yalRxnd7HjbGkt/ruuVapUQUkIiSbXXXed0hlN3PxiM+fg+nOcb94pcmZMaCj+ja7Tp09HSQiJBl988YXSCU3s2SnDcba1cf7v9Vauzq5ip1ZmJfFvDSSERIOCggKpA2r79YYi54s3T3d+eMg3Enh3fjPxb3UdPHgwSkJIJFm5cqXS+Uy8b1iOc+K9oh87/xmdD9s4l/xbhvgYXQ8dOoSSEBJBlI5norP97NC/rBgRHFzfSnyMri1atEBJCIkEEydOVDqdiQun5DmH3z5HvADAE++1du69uY74WF1Xr16NkhASAZQOp2uT3CqO87diseOfcb9P3ApIjzeUEBJOevfuLXU0bXe93ML5cp3c8ct6pOQcZ/7DjcTn0PXBBx9ESQgJB5988onSyUy86tJM54ctrcUOL4mRQl69yuJzGUgICQd16tjdlx/fWOR8XmbZL5gYKWz/kzuhF7L9+vVDSQix4cUXX1Q6l4mTflnPvQBIHT2QztY2zpXdMsXn1LU0LyEhxAKlY+lauVIFx9kZeOLPnxgxHH2nSHxeXevXr4+SEBIKd999t9KpTFz5dBPn6w3+l/2CeXxTkTPxjrric+u6ZMkSlIQQE06dOqV0JhOLC6s6zg5504+JGEGkVJRfw0BCiAmdOnWSOpK2/1zV0jmwVu7UJmIEsWx6Y/E1dB0zZgxKQogOW7ZsUTqRibdcme2c/EB/2S+YGAUUNUsTX8tAQogO6enpUgfS9pSv8+9/Q+7MoYiRxMcrC8XX0rVr164oCSGBmDlzptJ5TJw+roFz9F3zZb9g4qIyuK+bFCRkd+zYgZIQEgCl4+iaWT3FDe4hdWBbMaL4/n278GE1atRASQiRGDp0qNJpTHxrXoFz6K3Ql/2Cecw3spg6xl3bD9k5c+agJISU5ciRI0pnMfGi9tXck3xSxw2nOCdQLd0unLhPQkhZWre2G15/sfYcn3KnDadf+UYYb85pKr4HXUeMGIGSEALWrVundBITR91Y2/luc/iW/YKJqEIdz7VbqTh+/DhKQogPpYOYiAi/4Vz2CyZGGggeIr0XXdu1a4eSkORm8uTJSucw8Q8P5jpHSsK/7BfM730jjjuuqyW+J11LSkpQEpLUKB1D1wZ1Kkds2S+YGHHgyLD0vnStVMnNRUBIcjJw4EClU5i4ZXFzN7uP1EGjIbIKzZqYK743XadNm4aSkORi//79SmcwsU+X6j/J7hMrMQLJqcWsQoQYkZ+fL3UEbQ+XnGMU5itSYgSyeaFdVqFBgwahJCQ5WLZsmdIJTPyP4TnOt5uiP/HnT4xEenWqLr5XXQ8cOICSkKRA6QAmOjtiM/HnT2QV+mrDOeJ71bVpU3dzESGJzYQJE5TGb+KfpuUHzO4TK5Fv8L5hdtGLX331VZSEJDRKw9e1RePUkIN8RkPsEJTet6GEJCY9e/aUGry2Hy0v1MruEysxMln4WJ743nUtzX9ISGKxZ88epbGbOOjyLKPsPrESpwULclPFz2AgIYlFzZo1pYauLTL3fh7F/f6hihHKrlfssgr16dMHJSGJwQsvvKA0chMfHV3PORZCdp9YiZHK1T3tsgqV5kMkJCFQGriuVVMrBk3r7TUxUkFSEenz6JqTk4OSkPjmrrvuUhq3iWtmNXGDcEgdzcsiH+GkUfXEz6TrwoULURISn3z//fdKozbx/KL0sGT3iZVYskR+QumzGUhIfHLBBRdIDVrbf60JT3afWImsQq/OsMsqdM8996AkJL7YvHmz0phNvG1gTTcMt9Sx4klsWz63sKr4GQ0kJL5IS7NLpYWZ9GiG+YqUGMH8868txc+oa+fOnVESEh/8/ve/VxqxiTMmNHSDbUgdKh5FnkLkK5Q+q67btm1DSUhcoDRgXWtmVYq7Zb9gYiTzg+8iIH1eXTMyMlAS4m1uvvlmpfGa+M78Zs6hGIb5ipTIVzh9fAPxM+s6a9YslIR4k6+//lpptCZe8m8ZUcnuEysxskH+QumzG0iIN2nVyi5W/sH1p4NrSJ0nEUTewg3zCsTPruutt96KkhBv8frrryuN1cTRv6jtHviROk4iiRHORedVE+tA16NHj6IkxFMoDdVEBNNAth2p0ySSGOFgaVCqA12Li4tREuINHn74YaWRmjj/kUbOkZLEm/jzJ/IYIp+hVBe6rl+/HiUhnkBpoLrm1a+ScMt+wXSzCvluBaT60LVixYooCYkt/fv3Vxqnidv/1MLTYb4iJfIZzp3USKwTXadMmYKSkNiwb98+pVGaeGW3Gm5+PamDJIMY+TTMqSzWjYGExIbcXLu8eNgc44XsPrESWYWQ31CqG11L8ysSEl2WLl2qNEYTH7izrhs1R+oYySSyCvW5yC6rUGmeRUKiitIQda3o08vx/aMpRkCHS+zCh5XmWSQkOowbN05phCYu+11jN1iG1CGSUeQ5nHC7GwMwZJcvX46SkKigNEBdiwrS+OsviMAhUn0ZSkhk6d69u9TwtP1kZWFch/mKlMgqhLyHUp3pWpp3kZDIsGvXLqXRmTi4b7Zz6oPE3+8fqlgWRP5Dqe4MJCQyZGVlSQ1O2+83x0d2n1iJDVEf/aVQrDtde/XqhZKQ8DJ37lylsZk4dUx959i7XPYLJmIhDuptd6H96KOPUBISVpSGpmtG1fjL7hMrMULCsWipHnWtXds9aERIeLjjjjuURmbim3OaxmV2n1iJPIiTR9cX61LXBQsWoCTEjhMnTiiNy8QLi9Pds/5SQ6f+xYgpLdU98WcjIXacd955UsPSFo35Cy77GYsR05pZTcU61XXUqFEoCQmNd999V2lUJt4xqJY78y81cBpc5EVEfkSpbnU9efIkSkLMqVKlitKgTMRR30TI7hMrsWFq32t24cM6duyIkhAznnrqKaUxmfjsxNyEyu4TK5EfcfjAmmId6/r++++jJMQIpSHpWrdm4mX3iZVuVqEtduHDqlZ1k5MSoseNN96oNCITN7/YzA12ITVoai5GUsiXKNW1rjNmzEBJSGAOHjyoNB4Te3bKcINcSA2Zhq6zq9iplVlJrHMDCQlMixYtpIaj7dcbikLK7oOsOQgRJv1bInl8Y5Hz5Trz0RHyJb47v5lY57oOGTIEJSEyq1evVhqNifcNy3FOvGfWibH1FSGyV81o7Iy4tpYbM1/6u0QQqyL9u2e6t0jY82+6QoJ6Qv5Eqe51PXz4MEpCRJQGY6Lpjj/c257YVOR0v/Bso/7fZYkZJhwRkFY83fjHzzn459nurZJJZCSMrJA/8cxzhGJRkRt+jJCf8uCDDyqNxcRFU/LcoBZSwy2vmxhjRxtnoe8x5Z+noFFqQq4gIApS5Uo//axw3XMFRqHRcVDo3pvtsgq9+eabKAn5CUpD0bVprn52H9zLosH3uMD/UHbxY/oXk3gQ9/2T7qorflZ4y5W+0YDvAqETKQn5E22zCpVKyGn69esnNRBtd72sN2xH8Mtdr+hNMibKASJE/cUFQPqMZc2ukeIO8b8pCT6HgjyKCx6xyypUms+RJDt79+5VGoeJV1+a6U5oSQ21rPjVmvNf+olExg6tYzyh6EVRN6gj6TNKrpnVxDmpETYNI678+swqRCypX9/u3Dl+3QJl93GHrLuKnduvqSU+PpBfbTgnpCVFr4hR0d98oyPpswUSsQAwRyI95xnx3Dv+bLdkO2DAAJQkWXnppZeURmHipF/Wcy8AUgOF7hKf75eqy3nVxMcH89IL43tTET5700ahBfm8+Yps98IpPe8ZMZdyZTf90YXkZ599hpIkKUqD0BUz2oHi+2NUgF+x5vl2UW43/jE+txVjElNa5TDx0o7VHWd34DrG5inpsbo2auTOJZBkY8yYMUpjMHHl0038rmGf6fy5de2OE8Pa2ZWC/hJ6Tfe2Z3tYZuqdTm3TA14EkF8ReRalx+r68ssvoyRJhtIQdG3bsqrfe9TTa/zFTn4D+85/xhn3N4yro8WYvLxvWB3xs4TixedXC3gRxEgspaL8WANJsnDxxRdLDUDbvX9t6XfNGg21uNA9fhpWQ9k6GwsxaYnJS+kz2DigR6bfvRYYiS2bfnaXYSiOHz8eJUl0tm/frnz5Jg7tX9M5+b68TIUG2rdrDfFxtt52tf/X9ZKYtOzVyS7dtz/vG5rjd9cgRgFFzdLExxlIEp3q1e0aJ1J7Sb/E+O//+e92GW6D+a/V/kceXhCTlZsX2p3YC+aLk/PElRfUC/IuSo/RtUePHihJojJ79mzlSzdx+rgG4pFd7Ex7bVYT8THhtF0r/3MPXhAjoJya1mf2g4oDU9hSXf71cRG+qW+2+Bhdd+/ejZIkKMoXrmtm9RRxIgohv3EPKj0mEq56pol7j13+fcRaTFIiDqL0niMhbjXKj8Tw/xFDUPp7XbOz3QsISTSGDx+ufNkmvjWvwA3aUbbBQVwUcutab0nVtkpl76UZc1c+fB1Ser+RsluHau5qS/n3gvyLyMMoPUbXefPmoSSJwrFjx5Qv2cQu7X2N7UN16I3gHRNut1uDDsWHguxAjLbIfXDnIPOtzra+8HCeuDyKC2RGeor4GANJotC2bVvpC9b2i7XnKNl9Dqxr5fzjVbtJJxuDnUGIlqgXjACk9xgNkUewfD0gqxDyMUp/r+vIkSNRknjn7bffVr5cE0fdWFsM04VfmXDs9AvVqzRPIUZa7Pjr1Da0sw7hECHCpNEZ3lfHc+2yCn333XcoSTyTkmI3FJQmmzDsnPWf0Zvw8idO2sUyfBjmRNY+Z/dLGw7XPqfOz7gjE18p/b2uHTp0QEnilalTpypfqol/mNTIOVIuQEUsJrz8ie3GsZwQDNO9trUZ6fLEaDjmJjZt2oSSxCnKF6prgzqVxWU/RPW55xd2MenC6YJH89x9COXfZ6TFfohplrPt4RSJQyJxsU5NdU9zknhj0KBBypdp4tbFzZVjuDjf/+0mu3XmSOhsL3aHu2XfayRFx7Jdb4+E0iYp3K7NttyfMH36dJQkXjhw4IDyJZrYp0t195ejfGPCr/8vb4j+clcwESUX0XLLv99IiR13v+hnt+MuEj41roEyCoAYyeXUYlahpKGgoED6ArXFkLr80hJ+9dDwpb/3ggfXnT6JV/Y9R0J3z30Mlz8DmZIiB2nBSO59yzMKN910E0ridVauXKl8eSZOGJ7j/tKXb0QYSj5ydz3xMV6wawd5OSzcooO1bm596i5iIqS6FKgFIzrbU4pfffUVSuJxlC/ORGl7qduA/lbspFapKD7GK5a8IG9XDpfoWMt/Z3fuPtK2apoqXggxOrI9s1FY6I58iFeZOHGi8qWZ+Odp+c7XQkIOnDx7Y3bs17uDidj6kVwWdCPv+IbZ0mt7yX+8Kh+bRqSiccPsjmy/9tprKIlHUb4wXQsb+0/JhfXkfhEK9BFuf/+bhs5RYX+8rdh6/F8jo3/uIRTvuqG237MSYYpVSLxG7969pS9K2z3LC8VddW6AS49s/NHVX9CSUMWEKE7ZSa/lRSv6mQyEiFa86DG7aMWTJk1CSbzCJ598onxJJg66PMvvvnrcN9o2mGg7BGHLfBcB6fOEorO1tTOgu138/Wi7cUEz5+A6eT4EI72CXLtw7T6JV8jJsbuvwxo6NvlIjQUHga7oFh/D/7L+c1V4wodhVLRzqV0Gnlg4cpD/2wB8Jt0cjf684oorUJJYs3DhQuXLMfHR0fXcI6VSQ4EYSkqP87rFzcMTPgyfv3HD2J16DFWEJgu0LOrmLOxpN6opzStJYozyxehaNTVwdB38UmxZ1Fx8bDy4ZGq+GDtPV5yrN0lo6jW/9N0C+IuZgBEfkopIj9O1QYMGKEmsGD16tPKlmIhMtGjkUgOB2PyD6DvSY73uE2MbiBuaTMUtEEZJ0mt43bmTGonLumfELcJDo+w+25IlS1CSaPPDDz8oX4aJ5xelBx0i48BLtwsyxMd7WUQqCkfnP+N377V2I/FKr+VlB/88O2g94BYHeR6lxxtIok3nzp2lL0Lbf60JPkmGNeN42PhyRuxUxIRmoN2A+Df88iHJCO6DIfY54HgvhszSYyAiEX9TEr3ox+Ewv34Vv4lEzojP9eoMu92NY8eORUmixdatW5UvwcThA2u6v+5Sgzgj7hEjkeIqkuLXzl+EoG9Kitxfu9Uzm7hBMn7WtprTLC/V3QCFsFpjh9RxNi1o5v6NtJce4lAN5hSk1/aquIhLn6WsGAki36P0eANJtKhWzS4GHX71gm2UwS8lYvBLj/eiWKqT8gUgNBY69RP3uRNWQUX+gyXT8t1OIdURNtK898fIZv8Jp9teau73onhGjASR71F6vK5du3ZFSSLNzJkzlco3EZFjMLknNYSy4lz5lHu8E/EmkIhRIG38wQQnjgmHkq3nwnPTfRfKNuJtEi6g2GwkPc5rzvvvRn5HNGXFLRHyPkrPoevOnTtRkgijVLyutbIqaR+WwXB62FXx0ciliEAYqmMzkPT3umKZFKsAUmwE3FtLj/Ga427NEdO5lTcc8R4yM919BSRSDBs2TKl0E9+Z30x7XRxzBLg3lp7HSz7+6/rK4R902HCFLnM31PhuIco+P8TmqYl3eP9w0DU9M7WjJaEep4/Xu1Xy53PPPYeShJtvvvlGqWwTu/mJH+9PDHPjYQccDiqVv1fHxFeHIutJrR8deX0tJTcCXhPLg9Lfe8kORelG5yIwQsQ8iPRcBpJw06aN3ZDz4HqzkFnoWF4PAHJltxrKagYmL19/NvyTl5gLKF9/GDLjwir9vVdsmFM56FJgWVF/bz9vF1JuxIgRKEm4WL9+vVLJJoYSNDNM58Yj6tyHGrmz8mXfN0YuHVrbZcSRHHFtLeVwDSZKdVcXYqUbJ9AwVBr+vst5ditNx48fR0nChFLBJqIzm4bNjocLACb5yuYsxLD82wgNy92sxOXW1DEqiIeTguXfdzAx0jmw1m6/Q/v27VESW6ZMmaJUrokLHkF2H72JvzOiI8VDAIzyk3MYvr4yPXIx+7A5qvyKAH4tpb/1kv7iPAYScx7ICyk9n64lJSUoiSVKxeqah62gmst+ZUVDP7Q+dhlvdS0/tMWQfHIED+6s+Z8mSrKUeBgp4bao7HvWET8Cthe3SpXc/RckVAYOHKhUqok7/hxa8kx8+fCyn1V3rr0sy3MO7Jnp3HJlTSWOAda7f3ObXXCUQL70eJ6y2xDzAoN6ZznX9MoU32usRSjw8vMkuuKCihOFUl3o+sQTT6Akpuzfv1+pTBMxQ24y+1teXAAwcehVpSAm2OE46a7IjQBWPN3Yvc0o/7q4CEjv0SuWf78mYgSJlQSpPgwkpuTn50sVqS1+Df0Fg0hU8ev8x8mRi1/4978U/mTSMRnELc/Wl+yCwtxwww0oiS7Lly9XKtHEB+6s60Z7kb7QRBYXvAPrIndaLxwhxuJRjCSRL1KqE12//PJLlEQTpQJ1rVhRnR1PJrGBKa+e9ZBV8aoe+ltqE01cWDEfINWLrs2auScoSTDuv/9+pfJMXPa7xlqnvxJVTHhFIo7fh0uCH6tNZHE4bMLtdhOsq1atQkmCoFScrkUFaUn9639G1EGW/X72H+1xYYbVhGqiiP0EUv0YSvzRq1cvqcK0/WRloXh+PdnEL/XHvrqQ6igU3SPBb8ivlUwiwOifn7CbnC7NX0nKs2fPHqWyTLypb7Z7OEX64pJRrIKsnGF/KOjvKwrFpb9kFcuCLZswq1DYqV3bbtslf6VUsRKyYV5oJ9tSKlZwPl3dMqnnUyQxutrzF7vRVZ8+fVCSM8yfP1+pJBOnjqnv7t2XvrBkF8NW1E1/g/Rmd91Qy90Gm8yTfoE8taW1c33vLLHudC3NZ0lKUSpI14z0wNl96OllLATFwCk3zGS3b/XTYCGIe9CpbbobXQiRhDDjbXp6MpnESBNLomXr0NS6dd1oSmTUqFFK5Zi49rmmvEfVFBcAhL3CxQC/8NjY47qtjRsUE2vd2AItPZb+VIyqJlsGjV20aBHK5OXkyZNKpZjY8dx047PelIZLjDyrpllHjUpeOnbsKFWItvi1Sra96SZiU5DNLzqGupwE9C/Crr82q6nYNnW95557UCYfmzdvVirDxDsG1XJTWklfDD19jzp5dH23xD29yf4ITP5hVQUXkGfub6hEHaZnxS3U+ZYh2ErzXCYXaWlpSkWYKEXDpafFnMhbc88u/911fS1n76qWbmM98V6RmyYMv+z4O4j/jaPEuFhgWIswX7dcmf3j4/dp5FFMVlEv+9bYBY+56KKLUCYPTz/9tFIJJj77QK5Wdp9kFZ1YCm2dVb2Sc2OfLHe2f9Fjec5fZzZx05+9OCXPmeIbLSDQiJQpVyeTcjKLyMy3D7RLIrNt2zaUSYNSAbrWraWf3ScZxQ5A2+QWkmtmNXHveaXXTHYxEnW22IUPy8hww6snPrfccovy4U3c/GIzJS4dPS0aIpb4pHqzFWnCeOH1L0akmC+R6k7XWbNmoUxcDh8+rHxoExHfDff+0hdAT3f+If3P3ruH20dH1xNDkdHTOruK3fyTUt0ZmLi0amU3WYLJKpPsPskkJqP+aZniWkdMFPLMhSzyTr473y51+m233YYy8XjjjTeUD2vifUNz3BlsqeLp6eWotoXhywfoz0GXZ7l74aX3QH3fw4dtnG4X2KVLO3r0KMqEQ/mgJnIW2r8IBvrqjMglBCnvnuWFPCjkR4xQbXNKFBe7gUcSh0ceeUT5kCZiySrU2O7JICIAVa4s110kLGycygnBAOI26de31BHrTte33noLZcKgfEBdm+aysQUSMfn/e1TkcgH4E5FxcNRYek/JLk5SOtvtwodVrOieMYh/BgwYoHw4E3e9Elp2n2QQk3HY5ivVWzQMJedesoh8lAsetcsq9Pjjj6OMX/bt26d8KBOv7pkZUl63ZBF1g917Ut1FQ8QWwAVIem/UNwrwjVzzG1QR687A+KVRI7srIEJacclJFqMijI6keoumR95JvgxMuuI7Qn5Kqd50vfbaa1HGH0uXLlU+jIm4r8X9rVSx9PSvS0Ej6+CU1v78YrscjIku6qZ/d7tR2ueff44y7lA+iK5VKvvuLznx51esiCx+LHI5AE1F0hBuz5bF6AjnM6R607VJEze6c/wwfvx45UOYiDXt8mmo6Vm9lpO/Yd3KvGAHELeyyFcp1Z2uK1asQBk3KB9A13Ytq3LTTwBP+BrT+FvtUlRFwnkPNXJnvqX3TH0X7Z3FTkqKXHcGep/u3btLb1zbvX9l8Al/YpcZ1t6levOC2AbLIC2yOMeCvJVSvelamjfTu+zevVt50yYOHVDTjU4rVSD1/Ypsa+Nc9jO7NNWR9O6baruhxKT3Tk+PAlo3s4uE5dO7ZGfbHUVFai/+gshiku39RXYnzaLhl77RG09symJki/yVUr3petlll6H0HvPmzVPerInTf9OAwScDiLPm9WqHP+9/uO16foZ7KyB9BtrK/ZFDHkup7nQtzaPpOZQ3qitSWXMW2b8I4hmJnP+RsuT5AiZr8SNGuIghKNWbrqV5NL3DyJEjlTdp4oa5bDD+dOPN+e79pXrzqtk1fBd034hF+jz09L6AaWPssgotWLAAZez57rvvlDdnYpf21ThkDCAm1UZeX0usOy/79H/wli6QGPFmpKuRmw2NPR06dJDemLZfrGWYL38i6xF2kkn1Fg/isBIndWUx4kVeS6nedP3Vr36FMnZs3LhReVMmjrqRy0aBxI6/zu2qiXUXD956FZd1A4nvt9O5dt/vqVOnUMaGKlXsjjpy44h/8Qux/g9ns/vEq59yY5df3RGer/1L9aZraX7N6PPUU08pb8bEuZO4dTSQuEeskWF9jxhz27fi1u5AIr/lnZZzPB988AHKqKO8EV0b1KnMWeIAYpb4yfvCn90nViIFGQ93yYZjlSc93U1OGj0GDx6svAkTt77E46P+RIPAfbNUb/FqahVmFQoksgrNfsBun8czzzyDMvIcOnRIeXETf35xdQaQCCCy+5TNzJsoPnI3swoFEiNi5L2U6s7AyFNYaLeX+UgJQ0j5083usyry2X1i5bebmFXIn+5Zj4V2Zz2GDBmCMnKsWbNGeVETGUQysDgtdm6LyGf3iZXXXZbFIK8BxFxAL8vTnkeOHEEZMZQXNJFhpP2L1NtzJ8XPfv9QLXmhgGHe/ejGe9hgF++hqMgNPxZ+Jk2apLyYiUwkEVjcFv19RaHTv3sNsf4SQWwM2vdaS+79CCDyX44bZhfxae3atSjDjvJCujKVlJ64CGCI/PHKQufi8+J3B2B5cVHDrxvWvNn5gxummI/ho1+/ftILaLvnL0wmaSImA7FSssc3Irj8Iu9GAArmDX2y3M+DM/A876FvOKI+P/rooyjt2bt3r/LkJjKddOjiQoDOg23Bv7zRPQMeF/52RI4bCRfnPLDdVfpsNLAYMRfkWud9sKdBA7sdaWgEXPqxE7+eSJKCLbV/mpZvnX8+Eva7pIa74w8NFzsZ+Z3bGY7MT1dffTXK0FmyZInypCZOGV2fmz/CLLbUYqegs7W1G4q778WxmzS8+tJM94KE5Svc3zOoS3gNR+7Hzz77DGXIKE+oa9VUbv+MpJhMw6oKRljYP7BlcXPnoVH1nMs7V3eqprmppcMqovzgYoNINjtfbuG+JvLgc49/5MQoCrdS0veha16eO5dgztixY5UnM3HNrKbu2rb0wWj4xZARe8rdC8KHbdwNVxvmFTgzf9vQGTOkjjOwV6ZzUftqTov8VKdurcpuNBrs0U/zXairV0tx6tep7LRskuZ07VDNub53lvOb23LcOISb/tjMnYfArzyeGzs5ebw3euLWD3kypT6m6yuvvILSGOWJdD2/KJ1HQGMsRgjYXooZ5WO+e3L8WuPWAcNKrDCgQ/9E33/DvyFgJdaicR+Px+LCsl94fho9MdqqUtl6VKdP165dpSfQdt8aBoGgNFziNmvVM26C0JAtzdcZnJ07dyoPNnH4wJrur4j0QSiloYkRdduW1udEglOjht2sMoaR3O1FaXjFiBrh1aQ+p2uPHj1Q+mfOnDnKg0z8w4O57oQRhiyU0vCKuYA7r7MLH1aav9MvygN0xbIfMsIsmZpPKY2A2HOxZpbdXEDNmjVRqowYMUL5Y0pp4vn888+jPMu3336r/BGlNKE9S7t27aQ/oJQmqKX5PCtU2LFjh/KPlNKksEKFa665RvoHSmmC60b5ysrKEv+RUprYXnLJJSjlf6SUJratWrVyKqSlpYn/SClNbDt37uxU6NWrl/iPlNLE1j0gZJvsg1Ianx4+fBhlhQrNmzdX/pFSmrgOHToU5VkyM+1ij1FK48MuXbqgVLENA0Yp9bazZ89GGZgtW7Y4iAi8aNEiZ/HixZTSOBV9eOnSpc7HH38cvOMTQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEELCT4UK/w9ZtpLF63tVWgAAAABJRU5ErkJggg==";

	for (var iTs = -max * ((mapsizeX + 2) / 2); iTs < max * ((mapsizeX + 2) / 2); iTs = iTs + max) {
		for (var jTs = -max * ((mapsizeY + 2) / 2); jTs < max * ((mapsizeY + 2) / 2); jTs = jTs + max) {
			var i = iTs;
			var j = jTs;
			if (i > -max * ((mapsizeX + 2) / 2))
				DrawMyRect(i, j, i + (max / mysize1), j + (max), "#FFFF00",_ctx);
			if (j > -max * ((mapsizeY + 2) / 2))
				DrawMyRect(i, j, i + (max), j + (max / mysize1), "#FFFF00",_ctx);
			if (i < max * ((mapsizeX + 2) / 2) - max)
				DrawMyRect(i + (max / mysize1 * (mysize1 - 1)), j, i + max, j + (max), "#FFFF00",_ctx);
			if (j < max * ((mapsizeY + 2) / 2) - max)
				DrawMyRect(i, j + (max / mysize1 * (mysize1 - 1)), i + max, j + (max), "#FFFF00",_ctx);

			if (i2 >= 0)
				if (j2 >= 0) {
					DrawMyRect(i + (max / mysize1), j + (max / mysize1), i + (max) - (max / mysize1), j + (max) - (max / mysize1), "rgba(150,150,150," + map[i2][j2][1] + ")",_ctx);
				}
			j2 = j2 + 1;
		}
		j2 = -1;
		i2 = i2 + 1;
	}
	i2 = -1,
	j2 = -1;
	for (var iTs = -max * ((mapsizeX + 2) / 2); iTs < max * ((mapsizeX + 2) / 2); iTs = iTs + max) {
		for (var jTs = -max * ((mapsizeY + 2) / 2); jTs < max * ((mapsizeY + 2) / 2); jTs = jTs + max) {
			var i = iTs;
			var j = jTs;
			if (i2 >= 0)
				if (j2 >= 0) {
					if (((map[i2][j2][0] >> 0) & 1) == 1)
						DrawMyRect(i - (max / mysize2), j - (max / mysize2), i + (max / mysize2), j + (max / mysize2 * (mysize2 + 1)), "#FFFF00",_ctx);

					if (((map[i2][j2][0] >> 3) & 1) == 1)
						DrawMyRect(i - (max / mysize2), j - (max / mysize2), i + (max / mysize2 * (mysize2 + 1)), j + (max / mysize2), "#FFFF00",_ctx);

					if (((map[i2][j2][0] >> 1) & 1) == 1)
						DrawMyRect(i + (max / mysize2 * (mysize2 - 1)), j - (max / mysize2), i + max + (max / mysize2), j + (max) + (max / mysize2), "#FFFF00",_ctx);

					if (((map[i2][j2][0] >> 2) & 1) == 1)
						DrawMyRect(i - (max / mysize2), j + (max / mysize2 * (mysize2 - 1)), i + max + (max / mysize2), j + (max) + (max / mysize2), "#FFFF00",_ctx);

					if (map[i2][j2][6] == "1") {
						_ctx.beginPath();
						_ctx.arc(mapX + mapZ * ((-max * ((mapsizeX + 2) / 2)) + (i2 + 1.8) * max), mapY + mapZ * ((-max * ((mapsizeY + 2) / 2)) + (j2 + 1.8) * max), mapZ, 0, 2 * Math.PI);
						_ctx.fillStyle = '#FFFFFF';
						_ctx.fill();
					}
					if ((map[i2][j2][4] != "$") && (map[i2][j2][4] != "")) {
						if (Math.floor(mapZ * 5) > 2) {
							_ctx.fillStyle = '#FFFFFF';
							_ctx.font = Math.floor(mapZ * 5) + 'px Arial';
							_ctx.fillText(map[i2][j2][4], mapX + mapZ * ((-max * ((mapsizeX + 2) / 2)) + (i2 + 1.08) * max), mapY + mapZ * ((-max * ((mapsizeY + 2) / 2)) + (j2 + 1.32) * max));
						}
					}
					if ((map[i2][j2][5] != "$") && (map[i2][j2][5] != "")) {
						if (Math.floor(mapZ * 5) > 2) {
							_ctx.fillStyle = '#FFFFFF';
							_ctx.font = Math.floor(mapZ * 5) + 'px Arial';
							_ctx.fillText(map[i2][j2][5], mapX + mapZ * ((-max * ((mapsizeX + 2) / 2)) + (i2 + 1.08) * max), mapY + mapZ * ((-max * ((mapsizeY + 2) / 2)) + (j2 + 1.9) * max));
						}
					}
				}
			j2 = j2 + 1;
		}
		j2 = -1;
		i2 = i2 + 1;
	}
	DrawMyRect((-max * ((mapsizeX + 2) / 2)) + max - (max / mysize2), (-max * ((mapsizeY + 2) / 2)) + max - (max / mysize2), (-max * ((mapsizeX + 2) / 2)) + max + (max / mysize2), (max * ((mapsizeY + 2) / 2)) - max + (max / mysize2), "#FFFF00",_ctx);
	DrawMyRect((-max * ((mapsizeX + 2) / 2)) + max - (max / mysize2), (-max * ((mapsizeY + 2) / 2)) + max + (max / mysize2), (max * ((mapsizeX + 2) / 2)) - max + (max / mysize2), (-max * ((mapsizeY + 2) / 2)) + max - (max / mysize2), "#FFFF00",_ctx);

	DrawMyRect((-max * ((mapsizeX + 2) / 2)) + max - (max / mysize2), (max * ((mapsizeY + 2) / 2)) - max + (max / mysize2), (max * ((mapsizeX + 2) / 2)) - max + (max / mysize2), (max * ((mapsizeY + 2) / 2)) - max - (max / mysize2), "#FFFF00",_ctx);
	DrawMyRect((max * ((mapsizeX + 2) / 2)) - max - (max / mysize2), (-max * ((mapsizeY + 2) / 2)) + max - (max / mysize2), (max * ((mapsizeX + 2) / 2)) - max + (max / mysize2), (max * ((mapsizeY + 2) / 2)) - max + (max / mysize2), "#FFFF00",_ctx);
}
function DrawMyRect(a, b, c, d, color,_ctx) {
	_ctx.fillStyle = color;
	var mapX=Math.floor(320/2);
	var mapY=Math.floor(320/2);
	var mapZ=320/200;
	_ctx.fillRect(mapX + mapZ * a, mapY + mapZ * b, mapZ * (c - a), mapZ * (d - b));
}


var ___login = GetVal("login", '');
var ___password = GetVal("password", '');
Serv_login(___login, ___password, game_onlogin);
var players_mode_g=0;
function game_onlogin(g) {
	if (g == 1) {
		var now = new Date();
		if (document.location.href.split('/')[document.location.href.split('/').length - 1] == "admin_run_tur.html") {
			update_tab(0);
			setInterval(run_tur_interv, 100);
			document.getElementsByName('u')[2].value = new Date(Math.floor((now.getTime() - now.getTimezoneOffset() * 60000) / 60000 / 5 + 1.3) * 60000 * 5).toISOString().substring(0, 16);
			Serv_Command('_proj_list_', parse__proj_list);
		}
		if (document.location.href.split('/')[document.location.href.split('/').length - 1] == "admin_add_in_group.html") {
			players_mode_g=0;
			Serv_Command('_get_players_no_group_', parse_players_list);
			Serv_Command('_get_stat_players_', parse_stat_list);
		}
		if (document.location.href.split('/')[document.location.href.split('/').length - 1] == "admin_del_from_group.html") {
			players_mode_g=1;
			Serv_Command('_get_players_in_group_', parse_players_list);
			Serv_Command('_get_stat_players_', parse_stat_list);
		}
		if (document.location.href.split('/')[document.location.href.split('/').length - 1] == "admin_posts.html") {
			Serv_Command('get_programs',function (a){parse_programs(JSON.parse(a))});
		}
		if (document.location.href.split('/')[document.location.href.split('/').length - 1] == "admin_tasks.html") {
			Serv_Command('get_prog_list', function (a){parse_prog_list(JSON.parse(a))});
		}

	} else {
		sessionStorage.clear();
		document.location.href = "/login.html";
	}
	//Serv_LoadFile('\\task\\all.json', ParseTabs);
}
function GetName(ii)
{
   var a=0;
   var b=0;
   a = ii;
   var ConvertToLetter = "";
   while(ii > 0)
   {
      a = Math.floor((ii - 1) / 26);
      b = (ii - 1) % 26;
      ConvertToLetter = String.fromCharCode(b + 65) + ConvertToLetter;
      ii = a;
   }
   return ConvertToLetter;
}
var arr_prog_list;
var arr_select_proj;
var arr_select_task;
function parse_prog_list(arr)
{
	console.log(arr);
	arr_prog_list=arr;
	if (GetVal('proj_name','')!='' && GetVal('server','')!='' && GetVal('OpenEditor_task','')!='' && GetVal(GetVal('OpenEditor_task',''),'')!='')
	{
		parse_prog_list_serv_list();
	}
	for (var i=0;i<arr.length;i++)
		document.getElementsByClassName('login')[0].innerHTML+='<button  style="height: 30px;width: 690px;margin: 5px;  background: #5f3d71;" onclick="sel_proj('+i+')" class="back">'+(arr[i].name+' ('+arr[i].folder+')').slice(0,90)+(((arr[i].name+' ('+arr[i].folder+')').length>=90)?'...':'')+'</button>';
}
function parse_prog_list_serv_list(s)
{
	for (var j=0;j<arr_prog_list.length;j++)
		if (arr_prog_list[j].name==GetVal('proj_name',''))
		{
			sel_proj(j);
			for (var k=0;k<arr_select_proj.tasks_info.length;k++)
				if (arr_select_proj.tasks_info[k].name==GetVal('OpenEditor_task',''))
				{
					sel_task(k);
					return;
				}
		}
	
	
}
var def_select_tasks_div_val='';
function sel_proj(ind)
{
	arr_select_proj=arr_prog_list[ind];
	console.log(arr_select_proj);
	document.getElementById('select_proj_div').style.display='none';
	document.getElementById('select_tasks_div').style.display='';
	document.getElementById('select_tasks_div_name').innerHTML=arr_select_proj.name;
	if (def_select_tasks_div_val=='')
		def_select_tasks_div_val=document.getElementById('select_tasks_div').innerHTML;
	document.getElementById('select_tasks_div').innerHTML=def_select_tasks_div_val;
	for (var i=0;i<arr_select_proj.tasks_info.length;i++)
		document.getElementById('select_tasks_div').innerHTML+='<button  style="height: 30px;width: 690px;margin: 5px;  background: #5f3d71;" onclick="sel_task('+i+')" class="back">'+(arr_select_proj.tasks_info[i].name+' ('+arr_select_proj.tasks_info[i].folder+') ('+GetName(i+1)+')').slice(0,120)+'</button>';
	
}
function sel_task(ind)
{
	document.getElementById('select_tasks_div').style.display='none';
	document.getElementById('select_task_div').style.display='';
	arr_select_task=arr_select_proj.tasks_info[ind];
	console.log(arr_select_task);
	if (arr_select_proj.name.length>40)
	{
		document.getElementById('select_task_div_name').innerHTML='Задача "'+arr_select_task.name+'" в "'+arr_select_proj.name.slice(0,38)+'..."';
	}else
	{
		document.getElementById('select_task_div_name').innerHTML='Задача "'+arr_select_task.name+'" в "'+arr_select_proj.name+'"';
	}
	var s='';
	s+='Название: '+arr_select_task.name+'</br>';
	s+='Расположение: '+arr_select_proj.folder+'task/'+arr_select_task.folder+'</br>';
	s+='Решение:</br>';
	if (arr_select_task.solution.trim()=='')
		s+='<textarea id="programm_text" style="width:100%;height:200px;resize: none;-moz-tab-size : 2;-o-tab-size : 2;tab-size : 2;" disabled>Отсутствует</textarea></br>';
	else
		s+='<textarea id="programm_text" style="width:100%;height:200px;resize: none;-moz-tab-size : 2;-o-tab-size : 2;tab-size : 2;" disabled>'+INI2Text(arr_select_task.solution)+'</textarea></br>';
	s+='Тесты:</br>';
	for (var i=0;i<arr_select_task.tests.length;i++)
	{
		s+='<canvas id="canv_'+i+'" style="width: 320px; height: 320px;margin:7px;"></canvas>';
	}
	setTimeout(function(){
	for (var i=0;i<arr_select_task.tests.length;i++)
	{
		
		Render(document.getElementById('canv_'+i),StrToMap(INI2Text(arr_select_task.tests[i])));
		
	}
	},10);
	s+='</br>Стартовая программа:</br>';
	s+='<textarea id="programm_text" style="width:100%;height:200px;resize: none;-moz-tab-size : 2;-o-tab-size : 2;tab-size : 2;" disabled>'+INI2Text(arr_select_task.DefaultProgram)+'</textarea></br>';
	document.getElementById('task_div').innerHTML=s;
	
}
function resToStr(res)
{
	if (res.split(' ')[0]=="OK")
		return "OK";
	if (res.split(' ')[0]=="Error")
		return "Неполное решение "+res.split(' ')[1]+'%';
}
var all_programs=[];
var serv_time=0;
function INI2Text(s)
{
	return s.replace(/#09/g,'  ').replace(/#13/g,'\r').replace(/#10/g,'\n').replace(/#34/g,'"').replace(/#61/g,'=').replace(/#33/g,'!')
	
}
function open_post(i)
{
	console.log(all_programs[i]);
	document.getElementById('programm_div').style.display='';
	document.getElementById('programm_text').innerHTML=INI2Text(all_programs[i].programm);
	var s='';
	s+='Логин: '+all_programs[i].Login+'</br>';
	s+='Имя: '+all_programs[i].Name+'</br>';
	s+='Дата: '+all_programs[i].date+' ('+(new Date((new Date())-serv_time*1000+parseInt(all_programs[i].date)*1000)).toLocaleString()+')</br>';
	if (all_programs[i].exit_data!='')
	{
		s+='Комментарий проверки:</br>';
		s+='<textarea id="programm_text" style="width:100%;height:400px;resize: none;-moz-tab-size : 2;-o-tab-size : 2;tab-size : 2;" disabled>'+INI2Text(all_programs[i].exit_data)+'</textarea>';
		
	}
	s+='Вердикт: '+resToStr(all_programs[i].res)+'</br>';
	if (all_programs[i].task_name!=undefined)
	{
		s+='Название задачи: <a href="/admin_tasks.html">'+all_programs[i].task_name+'</a> (<a href="/index.html">Открыть в редакторе</a>)</br>';
		sessionStorage.setItem('OpenEditor_task',all_programs[i].task_name);
		sessionStorage.setItem('proj_name',INI2Text(all_programs[i].proj_name));
		sessionStorage.setItem(all_programs[i].task_name,INI2Text(all_programs[i].programm));
		sessionStorage.setItem('server',all_programs[i].uniID);
	}
	s+='Задание: '+GetName(parseInt(all_programs[i].task)+1)+'</br>';
	if (all_programs[i].task_name!=undefined)
		s+='Сервер: '+all_programs[i].uniID+' (основан на "'+INI2Text(all_programs[i].proj_name)+'")</br>';
	else
		s+='Сервер: '+all_programs[i].uniID+'</br>';
	document.getElementById('programm_raw').innerHTML=s;
}
function parse_programs(arr)
{
	console.log(arr);
	var s2='<tr><th>Логин</th><th>Имя</th><th>Время</th><th>Относительное время</th><th>Задание</th><th>Вердикт</th><th style="width: 100px;">Подробнее</th></tr>';
	serv_time=parseInt(arr.time);
	for (var i=0;i<arr.programs.length;i++)
		for (var j=0;j<arr.programs.length-1;j++)
			if (parseInt(arr.programs[j].date)<parseInt(arr.programs[j+1].date))
			{
				var tmp=arr.programs[j];
				arr.programs[j]=arr.programs[j+1];
				arr.programs[j+1]=tmp;
			}
	for (var i=0;i<arr.programs.length;i++)
		if (arr.programs[i].task_name!=undefined)
		{
			s2+='<tr><td>'+arr.programs[i].Login+'</td><td>'+arr.programs[i].Name+'</td><td>'+ (new Date((new Date())-serv_time*1000+parseInt(arr.programs[i].date)*1000)).toLocaleString()+'</td><td>'+ToText(-parseInt(arr.programs[i].date)+serv_time)+' назад</td><td>'+arr.programs[i].task_name+'</td><td>'+resToStr(arr.programs[i].res)+'</td><td><button  style="height: 100%;width: 100%;" id="id_btn_'+i+'" onclick="open_post('+i+');">Подробнее</button></td></tr>';
		}
		else
		{
			s2+='<tr><td>'+arr.programs[i].Login+'</td><td>'+arr.programs[i].Name+'</td><td>'+ (new Date((new Date())-serv_time*1000+parseInt(arr.programs[i].date)*1000)).toLocaleString()+'</td><td>'+ToText(-parseInt(arr.programs[i].date)+serv_time)+' назад</td><td>'+GetName(parseInt(arr.programs[i].task)+1)+' ('+arr.programs[i].uniID+')</td><td>'+resToStr(arr.programs[i].res)+'</td><td><button  style="height: 100%;width: 100%;" id="id_btn_'+i+'" onclick="open_post('+i+');">Подробнее</button></td></tr>';
		}
	all_programs=arr.programs;
	document.getElementById('top_tabl').innerHTML = s2;
}
function parse_stat_list(s)
{
	document.getElementsByName('r2')[0].innerHTML = 'У вас в группе: '+s.split('\n')[0].trim();
	document.getElementsByName('r2')[1].innerHTML = 'Зарегистрировано без группы: '+s.split('\n')[1].trim();
	document.getElementsByName('r2')[2].innerHTML = 'Всего игроков: '+s.split('\n')[2].trim();
}
function parse_players_list(s)
{
	var s2='<tr><th>Логин</th><th>Имя</th><th style="width: 100px;">Добавить</th></tr>';
	if (players_mode_g!=0)
		s2='<tr><th>Логин</th><th>Имя</th><th style="width: 100px;">Удалить</th></tr>'
	for (var i=1;i<s.split('\n').length;i++)
	if (s.split('\n')[i].trim()!='')
	{
		var v = MD5(Math.random() + '').slice(0, 10);
		if (players_mode_g==0)
		s2+='<tr><td id="id_login_'+v+'">'+s.split('\n')[i].split(';')[0]+'</td><td id="id_name_'+v+'">'+s.split('\n')[i].split(';')[1]+'</td><td><button  style="height: 100%;width: 100%;" id="id_btn_'+v+'" onclick="add_player(\''+s.split('\n')[i].split(';')[0]+'\',\''+v+'\');">Добавить</button></td></tr>';
		else
		s2+='<tr><td id="id_login_'+v+'">'+s.split('\n')[i].split(';')[0]+'</td><td id="id_name_'+v+'">'+s.split('\n')[i].split(';')[1]+'</td><td><button  style="height: 100%;width: 100%;" id="id_btn_'+v+'" onclick="del_player(\''+s.split('\n')[i].split(';')[0]+'\',\''+v+'\');">Удалить</button></td></tr>';

	}
	document.getElementById('top_tabl').innerHTML = s2;
	Serv_Command('_get_stat_players_', parse_stat_list);
}
function add_player(s,id)
{
	document.getElementById('id_login_'+id).innerHTML = 'Добавление...';
	document.getElementById('id_name_'+id).innerHTML = 'Добавление...';
	document.getElementById('id_btn_'+id).style.display = 'none';
	Serv_Command('_player_add_group_'+s+'_', parse_players_group);
	
}
function del_player(s,id)
{
	document.getElementById('id_login_'+id).innerHTML = 'Добавление...';
	document.getElementById('id_name_'+id).innerHTML = 'Добавление...';
	document.getElementById('id_btn_'+id).style.display = 'none';
	Serv_Command('_player_del_group_'+s+'_', parse_players_group);
}
function parse_players_group(s)
{
	if (s!='OK')
		alert(s);
	if (players_mode_g==0)
		Serv_Command('_get_players_no_group_', parse_players_list);
	else
		Serv_Command('_get_players_in_group_', parse_players_list);
}
function parse__proj_list(s)
{
	var obj = [];
	for (var i = 1; i < s.split('\n').length; i++)
		if (s.split('\n')[i].trim() != '') {
			obj[i - 1] = {};
			obj[i - 1]['folder'] = s.split('\n')[i].split(';_s_p_l_i_t_;')[0];
			obj[i - 1]['name'] = s.split('\n')[i].split(';_s_p_l_i_t_;')[1];
			obj[i - 1]['tasks'] = s.split('\n')[i].split(';_s_p_l_i_t_;')[2];
		}
	var s2='';
	for (var i = 0; i < obj.length; i++) {
		s2 += '<option value="'+i+'">'+obj[i].name+' ('+obj[i].folder+')</option> ';
	}
	document.getElementsByName('u')[0].innerHTML = s2;
	
}
var select_tab = 0, select_tab_arr = [];

var del_proj_f=0;
function del_proj()
{
	del_proj_f++;
	if (del_proj_f==2)
	{
		del_proj_f=0;
		document.getElementsByName('del_p')[0].innerHTML = 'Удалить';
		if (select_tab != 0)
		{
			Serv_Command('del_proj_'+select_tab_arr[1]+'_',del_proj_parse);
			SelectIt(0);
		}
	}else
		document.getElementsByName('del_p')[0].innerHTML = 'Нажмите ещё раз';
}
function del_proj_parse(s)
{
	if (s!='OK')
	{
		alert(s);
	}
	update_tab(0);
}


function SelectIt(ii, gg) {
	console.log([ii, gg]);
	del_proj_f=0;
	document.getElementsByName('del_p')[0].innerHTML = 'Удалить';
	select_tab_arr = gg;
	if (ii == 0) {
		document.getElementById('id_new_tur').style.display = '';
		document.getElementById('id_edit_tur').style.display = 'none';
		select_tab = 0;
	} else {
		document.getElementById('id_new_tur').style.display = 'none';
		document.getElementById('id_edit_tur').style.display = '';
		select_tab = ii;
		update_top_interv();
	}
}

function parse_update_tab(s, ii) {
	var obj = [];
	for (var i = 1; i < s.split('\n').length; i++)
		if (s.split('\n')[i].trim() != '') {
			obj[i - 1] = {};
			obj[i - 1]['name'] = s.split('\n')[i].split(';')[0];
			obj[i - 1]['can'] = s.split('\n')[i].split(';')[1];
			obj[i - 1]['start'] = s.split('\n')[i].split(';')[2];
			obj[i - 1]['freez'] = s.split('\n')[i].split(';')[3];
			obj[i - 1]['end'] = s.split('\n')[i].split(';')[4];
			obj[i - 1]['uniID'] = s.split('\n')[i].split(';')[5];
		}
	var s2 = '<button onclick="SelectIt(0)">Новый</button>';
	for (var i = 0; i < obj.length; i++) {
		if (obj[i].can == 'NOOK')
			s2 += '<button style="color:rgba(255,70,70,1)" title="Не доступен"';
		else
		if (obj[i].can == 'ONLY_YOU')
			s2 += '<button style="color:rgba(88,88,88,1)" title="Только администраторы"';
		else
		if (obj[i].can == 'YOU_AND_YOUR_GRUOP')
			s2 += '<button style="color:rgba(255,255,0,1)" title="Моя группа" ';
		else
			s2 += '<button  title="Все" ';
		s2 += 'onclick="SelectIt(' + (i + 1) + ',[\'' + obj[i].name + '\',\'' + obj[i].uniID + '\',' + obj[i].start + ',' + obj[i].freez + ',' + obj[i].end + '])">P' + (i + 1) + '</button>'
	}
	document.getElementById('id_tab').innerHTML = s2;
	if (ii >= 0)
		SelectIt(ii);
	else {
		var i = obj.length + ii;
		SelectIt(i + 1, [obj[i].name, obj[i].uniID, parseInt(obj[i].start), parseInt(obj[i].freez), parseInt(obj[i].end)]);
	}
}

function update_top_interv() {
	if (select_tab != 0)
		Serv_Command('_get_top_proj_'+select_tab_arr[1]+'_',ParseData);
}
setInterval(update_top_interv,10000);

function update_tab(ii) {
	Serv_Command('_my_server_list_', parse_update_tab, ii);
}

function run_tur_interv() {
	if (select_tab != 0) {
		var now = new Date();
		var ansv=[];
		ansv[0] = 'Название: ' + select_tab_arr[0] + ' (uniID: ' + select_tab_arr[1] + ')';
		if (select_tab_arr[2] - now.getTime() / 1000 >= 0)
			ansv[1] = 'Старт: ' + new Date(select_tab_arr[2] * 1000 - now.getTimezoneOffset() * 60000).toMyISOString() + ' (через ' + ToText(select_tab_arr[2] - now.getTime() / 1000) + ')';
		else
			ansv[1] = 'Старт: ' + new Date(select_tab_arr[2] * 1000 - now.getTimezoneOffset() * 60000).toMyISOString() + ' (было ' + ToText(now.getTime() / 1000 - select_tab_arr[2]) + ' назад)';
		
		
		if (select_tab_arr[3] < 0)
			ansv[2] =  'Заморозка: не замораживать';
		else
			if (select_tab_arr[3] > 2 * 365 * 24 * 60 * 60)
				ansv[2] = 'Заморозка: сразу';
			else
			{
				ansv[2] = 'Заморозка: за ' + ToText(select_tab_arr[3]) + ' до конца ';
				if (select_tab_arr[4] + select_tab_arr[2] - now.getTime() / 1000 - select_tab_arr[3] >= 0)
					ansv[2] += '(через ' + ToText(select_tab_arr[4] + select_tab_arr[2] - now.getTime() / 1000 - select_tab_arr[3])+')';
				else
					ansv[2] += '(было ' + ToText(0-select_tab_arr[4] - select_tab_arr[2] + now.getTime() / 1000 + select_tab_arr[3])+')';
			}
		
		
		ansv[3] = 'Продолжительность: ' + ToText(select_tab_arr[4])+' ';
		if (select_tab_arr[4] + select_tab_arr[2] - now.getTime() / 1000 >= 0)
			ansv[3] += '(Конец через ' + ToText(select_tab_arr[4] + select_tab_arr[2] - now.getTime() / 1000)+')';
		else
			ansv[3] += '(Конец был ' + ToText(0-select_tab_arr[4] - select_tab_arr[2] + now.getTime() / 1000)+' назад)';
		if (document.getElementsByName('r')[0].innerHTML!=ansv[0])
			document.getElementsByName('r')[0].innerHTML=ansv[0];
		if (document.getElementsByName('r')[1].innerHTML!=ansv[1])
			document.getElementsByName('r')[1].innerHTML=ansv[1];
		if (document.getElementsByName('r')[2].innerHTML!=ansv[2])
			document.getElementsByName('r')[2].innerHTML=ansv[2];
		if (document.getElementsByName('r')[3].innerHTML!=ansv[3])
			document.getElementsByName('r')[3].innerHTML=ansv[3];
		return;
	}
	var select_proj = parseInt(document.getElementsByName('u')[0].value);
	var name_tur = document.getElementsByName('u')[1].value;
	var start_tur = (new Date(document.getElementsByName('u')[2].value)) - 0;
	var end_tur = start_tur + parseInt(document.getElementsByName('u')[3].value) * 60;
	var freez_tur = start_tur + parseInt(document.getElementsByName('u')[3].value) * 60 - parseInt(document.getElementsByName('u')[4].value) * 60;
	var group_tur = document.getElementsByName('u')[5].value;
	var return_code = '';

	if (name_tur.length < 3)
		return_code = 'Поле с именем проекта содержит слишком мало символов';
	if (name_tur.length >= 32)
		return_code = 'Поле с именем проекта содержит слишком много символов';
	for (var i = 0; i < name_tur.length; i++)
		if (!('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZабвгдеёжзийклмнопрстуфхцчшщъыьэюяАБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ0123456789. '.indexOf(name_tur[i]) + 1))
			return_code = 'Поле с именем проекта содержит запрещёный символ (' + name_tur[i] + ')';
	if (start_tur > end_tur)
		return_code = 'Тур должен длиться положительное число минут';
	if (start_tur != start_tur)
		return_code = 'Cтарт isNAN';
	if (freez_tur != freez_tur)
		return_code = 'Заморозка isNAN';
	if (end_tur != end_tur)
		return_code = 'Продолжительность isNAN';
	if (document.getElementById('out_return_code').innerHTML != return_code)
		document.getElementById('out_return_code').innerHTML = return_code;
}

function run_tur() {
	if (select_tab != 0)
		return;
	run_tur_interv();
	if (document.getElementById('out_return_code').innerHTML != '') {
		alert(document.getElementById('out_return_code').innerHTML);
		return;
	}
	var select_proj = parseInt(document.getElementsByName('u')[0].value);
	var name_tur = document.getElementsByName('u')[1].value;
	var start_tur = (new Date(document.getElementsByName('u')[2].value)) - 0;
	var end_tur = start_tur + parseInt(document.getElementsByName('u')[3].value) * 60000;
	var freez_tur = start_tur + parseInt(document.getElementsByName('u')[3].value) * 60000 - parseInt(document.getElementsByName('u')[4].value) * 60000;
	var group_tur = document.getElementsByName('u')[5].value;
	var v = MD5(Math.random() + '').slice(0, 10);
	//(proj parent)_(visib name)_(time_start)_(time_freeze)_(time_end)_(group)_(uniID)_
	Serv_Command('create_proj_' + select_proj + '_' + name_tur + '_' + Math.floor(start_tur / 1) + '_' + Math.floor(freez_tur / 1) + '_' + Math.floor(end_tur / 1) + '_' + group_tur + '_' + v + '_', add_proj_acc);
}
function add_proj_acc(s) {
	if (s != 'OK') {
		alert(s);
		return;
	}
	update_tab(-1);

}
//Server---Server---Server---Server---Server---Server---Server
function swap(items, firstIndex, secondIndex){
    var temp = items[firstIndex];
    items[firstIndex] = items[secondIndex];
    items[secondIndex] = temp;
}
function partition(items, left, right) {
    var pivot,pivot_s
        i       = left,
        j       = right;
	pivot = -(parseFloat(items[Math.floor((right + left) / 2)][2])*1000000-parseFloat(items[Math.floor((right + left) / 2)][3]));
	pivot_s = items[Math.floor((right + left) / 2)][1];
    while (i <= j) {
        while ((-(parseFloat(items[i][2])*1000000-parseFloat(items[i][3])) < pivot)||((-(parseFloat(items[i][2])*1000000-parseFloat(items[i][3])) == pivot)&&(items[i][1]<pivot_s))) {
            i++;
        }
        while ((-(parseFloat(items[j][2])*1000000-parseFloat(items[j][3])) > pivot)||((-(parseFloat(items[j][2])*1000000-parseFloat(items[j][3])) == pivot)&&(items[j][1]>pivot_s))) {
            j--;
        }
        if (i <= j) {
            swap(items, i, j);
            i++;
            j--;
        }
    }
    return i;
}
function QSORT(items, left, right) {
    var index;
    if (items.length > 1) {
        index = partition(items, left, right);
        if (left < index - 1) {
            QSORT(items, left, index - 1);
        }
        if (index < right) {
            QSORT(items, index, right);
        }
    }
    return items;
}
function ParseData(s)
{
	if (select_tab == 0 || select_tab_arr.length < 2)
		return;
	console.log(s);
	var arr=[];
	if (s.length==0)
		return;
	//debugger;
	for (var i=0;i<s.split('\n').length;i++)
		if (s.split('\n')[i].trim()!='')
		{
			arr[i]=[];
			if (i==0)
				arr[i][0]='Номер';
			else
			{
				arr[i][0]=i;
				for (var j=0;j<arr[0].length-1;j++)
					arr[i][arr[i].length]='0';
			}
			var __index=0;
			for (var j=0;j<s.split('\n')[i].split(';').length;j++)
				if (s.split('\n')[i].split(';')[j].trim()!='')
				{
					if (i==0)
					{
						if (s.split('\n')[i].split(';')[j].trim()=='names')
						{
							arr[i][arr[i].length]='Кто';
						}else
						if (s.split('\n')[i].split(';')[j].trim()=='scores')
						{
							arr[i][arr[i].length]='=';
						}else
						if (s.split('\n')[i].split(';')[j].trim()=='fine')
						{
							arr[i][arr[i].length]='штраф';
						}else
							arr[i][arr[i].length]=s.split('\n')[i].split(';')[j].trim();
					}
					else
					{
						__index++;
						if (__index<4)
						{
							arr[i][__index]=s.split('\n')[i].split(';')[j].trim();
						}
						else
						{
							for (var k=4;k<arr[0].length;k++)
							if (s.split('\n')[i].split(';')[j].trim().slice(1,-1)==arr[0][k])
							arr[i][k] = '100';
						}
					}
				}
		}
	//console.log(arr);
	arr=QSORT(arr, 1, arr.length - 1);
	//console.log(arr);
	var out_s='<tbody>';
	for (var i=0;i<arr.length;i++)
		{
			out_s+='<tr>';
			if (i==0)
				out_s+='<th>'+arr[i][0]+'</th>';
			else
				out_s+='<td>'+i+'</td>';
			for (var j=1;j<arr[i].length;j++)
				{
					if (i==0)
					{
						if (j<4)
							out_s+='<th>'+arr[i][j]+'</th>';
						else
						//if (my_access.indexOf(arr[i][j])<0)
						//	out_s+='<th title="'+arr[i][j]+'" style="color: #000000;text-decoration: underline;">'+GetName(j-3)+'</th>';
						//else
						out_s+='<th title="'+arr[i][j]+'" style="">'+arr[i][j]+'</th>';
					}
					else
					{
						if ((arr[i][j]==100)&&(j>2))
							out_s+='<td style="color: #0a0;">';
						else
							out_s+='<td>';
						out_s+=arr[i][j];
						out_s+='</td>';
					}
				}
			out_s+='</tr>';
		}
	out_s+='</tbody>';
	console.log(out_s);
	if (document.getElementById("top_tabl").innerHTML!=out_s)
		document.getElementById("top_tabl").innerHTML=out_s;
}


//Server---Server---Server---Server---Server---Server---Server
//Server---Server---Server---Server---Server---Server---Server
//Server---Server---Server---Server---Server---Server---Server
//Server---Server---Server---Server---Server---Server---Server
//Server---Server---Server---Server---Server---Server---Server
//Server---Server---Server---Server---Server---Server---Server
//Server---Server---Server---Server---Server---Server---Server
//Server---Server---Server---Server---Server---Server---Server
//Server---Server---Server---Server---Server---Server---Server
//Server---Server---Server---Server---Server---Server---Server
//Server---Server---Server---Server---Server---Server---Server
function pad(number) {
	if (number < 10) {
		return '0' + number;
	}
	return number;
}
Date.prototype.toMyISOString = function () {
	return pad(this.getUTCHours()) +
	':' + pad(this.getUTCMinutes())+
	' ' + pad(this.getUTCDate()) +
	'.' + pad(this.getUTCMonth() + 1) +
	'.' + this.getUTCFullYear();
};
function ToText(seconds) {
	interval = seconds / 31536000;
	if (interval > 1) {
		if (Math.floor(seconds / 2592000) % 12 != 0)
			return Math.floor(interval) + " г. и " + (Math.floor(seconds / 2592000) % 12) + " мес.";
		else
			return Math.floor(interval) + " г.";
	}
	interval = seconds / 2592000;
	if (interval > 1) {
		if (Math.floor(seconds / 86400) % 30 != 0)
			return Math.floor(interval) + " мес. и " + (Math.floor(seconds / 86400) % 30) + " дн.";
		else
			return Math.floor(interval) + " мес.";
	}

	interval = seconds / 86400;
	if (interval > 1) {
		if (Math.floor(seconds / 3600) % 24 != 0)
			return Math.floor(interval) + " дн. и " + (Math.floor(seconds / 3600) % 24) + " ч.";
		else
			return Math.floor(interval) + " дн.";
	}

	interval = seconds / 3600;
	if (interval > 1) {
		if (Math.floor(seconds / 60) % 60 != 0)
			return Math.floor(interval) + " ч. и " + (Math.floor(seconds / 60) % 60) + " мин.";
		else
			return Math.floor(interval) + " ч.";
	}

	interval = seconds / 60;
	if (interval > 1) {
		if (Math.floor(seconds % 60) != 0)
			return Math.floor(interval) + " мин. и " + Math.floor(seconds % 60) + " сек.";
		else
			return Math.floor(interval) + " мин.";
	}
	return Math.floor(seconds) + " сек.";
}
var MD5 = function (r) {
	function i(r, n) {
		return r << n | r >>> 32 - n
	}
	function c(r, n) {
		var t,
		o,
		e,
		u,
		a;
		return e = 2147483648 & r,
		u = 2147483648 & n,
		a = (1073741823 & r) + (1073741823 & n),
		(t = 1073741824 & r) & (o = 1073741824 & n) ? 2147483648 ^ a ^ e ^ u : t | o ? 1073741824 & a ? 3221225472 ^ a ^ e ^ u : 1073741824 ^ a ^ e ^ u : a ^ e ^ u
	}
	function n(r, n, t, o, e, u, a) {
		var f;
		return r = c(r, c(c((f = n) & t | ~f & o, e), a)),
		c(i(r, u), n)
	}
	function t(r, n, t, o, e, u, a) {
		var f;
		return r = c(r, c(c(n & (f = o) | t & ~f, e), a)),
		c(i(r, u), n)
	}
	function o(r, n, t, o, e, u, a) {
		return r = c(r, c(c(n ^ t ^ o, e), a)),
		c(i(r, u), n)
	}
	function e(r, n, t, o, e, u, a) {
		return r = c(r, c(c(t ^ (n | ~o), e), a)),
		c(i(r, u), n)
	}
	function u(r) {
		var n,
		t = "",
		o = "";
		for (n = 0; n <= 3; n++)
			t += (o = "0" + (r >>> 8 * n & 255).toString(16)).substr(o.length - 2, 2);
		return t
	}
	var a,
	f,
	C,
	g,
	h,
	v,
	d,
	S,
	l,
	m = Array();
	for (m = function (r) {
		for (var n, t = r.length, o = t + 8, e = 16 * (1 + (o - o % 64) / 64), u = Array(e - 1), a = 0, f = 0; f < t; )
			a = f % 4 * 8, u[n = (f - f % 4) / 4] = u[n] | r.charCodeAt(f) << a, f++;
		return a = f % 4 * 8,
		u[n = (f - f % 4) / 4] = u[n] | 128 << a,
		u[e - 2] = t << 3,
		u[e - 1] = t >>> 29,
		u
	}
		(r = function (r) {
			r = r.replace(/\r\n/g, "\n");
			for (var n = "", t = 0; t < r.length; t++) {
				var o = r.charCodeAt(t);
				o < 128 ? n += String.fromCharCode(o) : (127 < o && o < 2048 ? n += String.fromCharCode(o >> 6 | 192) : (n += String.fromCharCode(o >> 12 | 224), n += String.fromCharCode(o >> 6 & 63 | 128)), n += String.fromCharCode(63 & o | 128))
			}
			return n
		}
			(r)), v = 1732584193, d = 4023233417, S = 2562383102, l = 271733878, a = 0; a < m.length; a += 16)
		v = n(f = v, C = d, g = S, h = l, m[a + 0], 7, 3614090360), l = n(l, v, d, S, m[a + 1], 12, 3905402710), S = n(S, l, v, d, m[a + 2], 17, 606105819), d = n(d, S, l, v, m[a + 3], 22, 3250441966), v = n(v, d, S, l, m[a + 4], 7, 4118548399), l = n(l, v, d, S, m[a + 5], 12, 1200080426), S = n(S, l, v, d, m[a + 6], 17, 2821735955), d = n(d, S, l, v, m[a + 7], 22, 4249261313), v = n(v, d, S, l, m[a + 8], 7, 1770035416), l = n(l, v, d, S, m[a + 9], 12, 2336552879), S = n(S, l, v, d, m[a + 10], 17, 4294925233), d = n(d, S, l, v, m[a + 11], 22, 2304563134), v = n(v, d, S, l, m[a + 12], 7, 1804603682), l = n(l, v, d, S, m[a + 13], 12, 4254626195), S = n(S, l, v, d, m[a + 14], 17, 2792965006), v = t(v, d = n(d, S, l, v, m[a + 15], 22, 1236535329), S, l, m[a + 1], 5, 4129170786), l = t(l, v, d, S, m[a + 6], 9, 3225465664), S = t(S, l, v, d, m[a + 11], 14, 643717713), d = t(d, S, l, v, m[a + 0], 20, 3921069994), v = t(v, d, S, l, m[a + 5], 5, 3593408605), l = t(l, v, d, S, m[a + 10], 9, 38016083), S = t(S, l, v, d, m[a + 15], 14, 3634488961), d = t(d, S, l, v, m[a + 4], 20, 3889429448), v = t(v, d, S, l, m[a + 9], 5, 568446438), l = t(l, v, d, S, m[a + 14], 9, 3275163606), S = t(S, l, v, d, m[a + 3], 14, 4107603335), d = t(d, S, l, v, m[a + 8], 20, 1163531501), v = t(v, d, S, l, m[a + 13], 5, 2850285829), l = t(l, v, d, S, m[a + 2], 9, 4243563512), S = t(S, l, v, d, m[a + 7], 14, 1735328473), v = o(v, d = t(d, S, l, v, m[a + 12], 20, 2368359562), S, l, m[a + 5], 4, 4294588738), l = o(l, v, d, S, m[a + 8], 11, 2272392833), S = o(S, l, v, d, m[a + 11], 16, 1839030562), d = o(d, S, l, v, m[a + 14], 23, 4259657740), v = o(v, d, S, l, m[a + 1], 4, 2763975236), l = o(l, v, d, S, m[a + 4], 11, 1272893353), S = o(S, l, v, d, m[a + 7], 16, 4139469664), d = o(d, S, l, v, m[a + 10], 23, 3200236656), v = o(v, d, S, l, m[a + 13], 4, 681279174), l = o(l, v, d, S, m[a + 0], 11, 3936430074), S = o(S, l, v, d, m[a + 3], 16, 3572445317), d = o(d, S, l, v, m[a + 6], 23, 76029189), v = o(v, d, S, l, m[a + 9], 4, 3654602809), l = o(l, v, d, S, m[a + 12], 11, 3873151461), S = o(S, l, v, d, m[a + 15], 16, 530742520), v = e(v, d = o(d, S, l, v, m[a + 2], 23, 3299628645), S, l, m[a + 0], 6, 4096336452), l = e(l, v, d, S, m[a + 7], 10, 1126891415), S = e(S, l, v, d, m[a + 14], 15, 2878612391), d = e(d, S, l, v, m[a + 5], 21, 4237533241), v = e(v, d, S, l, m[a + 12], 6, 1700485571), l = e(l, v, d, S, m[a + 3], 10, 2399980690), S = e(S, l, v, d, m[a + 10], 15, 4293915773), d = e(d, S, l, v, m[a + 1], 21, 2240044497), v = e(v, d, S, l, m[a + 8], 6, 1873313359), l = e(l, v, d, S, m[a + 15], 10, 4264355552), S = e(S, l, v, d, m[a + 6], 15, 2734768916), d = e(d, S, l, v, m[a + 13], 21, 1309151649), v = e(v, d, S, l, m[a + 4], 6, 4149444226), l = e(l, v, d, S, m[a + 11], 10, 3174756917), S = e(S, l, v, d, m[a + 2], 15, 718787259), d = e(d, S, l, v, m[a + 9], 21, 3951481745), v = c(v, f), d = c(d, C), S = c(S, g), l = c(l, h);
	return (u(v) + u(d) + u(S) + u(l)).toLowerCase()
};

var RegistrationHash = function (h, p) {
	return MD5('Hash:' + h + ';Password:' + p + ';');
};
var GameLogin = '';
var GamePassword = '';
var Serv_iswork = false;
var newping = 0;
var get_errors = 0;
function Serv_Command(a /*string*/, f, iii, kkk) {
	if (GameLogin != '') {
		if (Serv_iswork == true) {
			if (a != "getpos")
				var timerId3546356 = setTimeout(function f567567() {
					Serv_Command(a, f, iii, kkk)
				}, 10);
			return;
		}
		Serv_iswork = true;
		newping = new Date;
		var XHR = ("onload" in new XMLHttpRequest()) ? XMLHttpRequest : XDomainRequest;
		var xhr = new XHR();
		xhr.open('GET', 'commands/' + GameLogin + '/' + a + '.txt', true);
		xhr.onload = function () {
			if (xhr.status == 200) {
				var XHR2 = ("onload" in new XMLHttpRequest()) ? XMLHttpRequest : XDomainRequest;
				var xhr2 = new XHR2();
				var xhr2 = new XHR2();
				xhr2.open('GET', '__/protect/' + RegistrationHash(this.responseText, GamePassword) + '.txt', true);
				xhr2.onload = function () {
					if (xhr2.status == 200) {
						Serv_iswork = false;
						if ('__PrOtEcT_NoT_CoMpLeTeD__' != xhr2.responseText) {
							get_errors = 0;
							ping = (new Date) - newping;
							f(xhr2.responseText, iii, kkk);
						} else {
							get_errors++;
							if (get_errors > 10) {
								document.writeln('Неверный логин или пароль (связь с сервером потеряна)');
								//alert('Неверный логин или пароль (связь с сервером потеряна)');
								//location.reload();
							}
							Serv_Command(a, f, iii, kkk);
						}
					} else
						xhr2.onerror();
				}
				xhr2.onerror = function () {
					document.writeln('Сервер не ответил(1.2).');
					console.log('Сервер не ответил(1.2).');
				}
				xhr2.send();
			} else
				xhr.onerror();
		}

		xhr.onerror = function () {
			document.writeln('Сервер не ответил(1.1).');
			console.log('Сервер не ответил(1.1).');
		}
		xhr.send();
	} else {
		document.writeln('Пользователь не залогинен.');
		console.log('Пользователь не залогинен.');

	}
}

function Serv_SendProgramm(Progr /*string*/, Task, f, leng, progress) {
	if (leng == undefined) {
		leng = 'kumir';
	}
	if (progress == undefined) {
		progress = '';
	}

	if (GameLogin != '') {
		if (Serv_iswork == true) {
			var timerId3546356 = setTimeout(function f567567() {
				Serv_SendProgramm(Progr, Task, f)
			}, 10);
			return;
		}
		Serv_iswork = true;
		newping = new Date;
		var XHR = ("onload" in new XMLHttpRequest()) ? XMLHttpRequest : XDomainRequest;
		var xhr = new XHR();
		xhr.open('GET', 'commands/' + GameLogin + '/upload;' + leng + ';' + Task + ';' + progress + ';.txt', true); // /upload;res;10%;A1;.txt
		xhr.onload = function () {
			if (xhr.status == 200) {
				var XHR2 = ("onload" in new XMLHttpRequest()) ? XMLHttpRequest : XDomainRequest;
				var xhr2 = new XHR2();
				xhr2.open('POST', '__/protect/' + RegistrationHash(this.responseText, GamePassword) + '.txt', true);
				//xhr2.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded'); // Отправляем кодировку
				xhr2.onreadystatechange = function () {
					if (xhr2.readyState == 4) {
						if (xhr2.status == 200) {
							Serv_iswork = false;
							if ('__PrOtEcT_NoT_CoMpLeTeD__' != xhr2.responseText) {
								get_errors = 0;
								f(xhr2.responseText);
							} else {
								get_errors++;
								if (get_errors > 10) {
									document.writeln('Неверный логин или пароль (связь с сервером потеряна)');
									//alert('Неверный логин или пароль (связь с сервером потеряна)');
									//location.reload();
								}
								Serv_SendProgramm(Progr, Task, f, leng, progress);
							}
						} else
							xhr2.onerror();
					}
				}
				xhr2.onerror = function () {
					document.writeln('Сервер не ответил(2.2).');
					console.log('Сервер не ответил(2.2).');
				}
				xhr2.send(encodeURIComponent(Progr).replace(/%20/g, "+")); // Отправляем POST-запрос
			} else
				xhr.onerror();
		}

		xhr.onerror = function () {
			document.writeln('Сервер не ответил(2.1).');
			console.log('Сервер не ответил(2.1).');
		}
		xhr.send();
	} else {
		document.writeln('Пользователь не залогинен.');
		console.log('Пользователь не залогинен.');

	}
}

function Serv_LoadFile(url /*string*/, f, iii, kkk) {
	var XHR = ("onload" in new XMLHttpRequest()) ? XMLHttpRequest : XDomainRequest;
	var xhr = new XHR();
	xhr.open('GET', url, true);
	xhr.onload = function () {
		if (xhr.status == 200) {
			if (this.status == 200) {
				f(this.responseText, iii, kkk);
			}
		} else
			xhr.onerror();
	}

	xhr.onerror = function () {
		document.writeln('Сервер не ответил(3.1).');
		console.log('Сервер не ответил(3.1).');
	}
	xhr.send();
}


function Serv_login(Login, Password, func) {
	var XHR = ("onload" in new XMLHttpRequest()) ? XMLHttpRequest : XDomainRequest;
	var xhr = new XHR();
	xhr.open('GET', 'commands/' + Login + '/login.txt', true);
	xhr.onload = function () {
		if (xhr.status == 200) {
			var XHR2 = ("onload" in new XMLHttpRequest()) ? XMLHttpRequest : XDomainRequest;
			var xhr2 = new XHR();
			xhr2.open('GET', '__/protect/' + RegistrationHash(this.responseText, Password) + '.txt', true);
			xhr2.onload = function () {
				if (xhr2.status == 200) {
					if (this.responseText=='OK' || this.responseText=='OKADMINOFADMIN' || this.responseText=='OKADMIN')
					{
						get_errors = 0;
					}
					else
					{
						get_errors++;
						console.log(this.responseText);
						if (get_errors>10)
						{
							SaveVal("password",'');
							document.location.href="/login.html";
						}else
							Serv_Command(Login, Password, func);
					}
					GameLogin = Login;
					GamePassword = Password;
					if (this.responseText=='OK')
						func(0);
					if (this.responseText=='OKADMIN')
						func(1);
					if (this.responseText=='OKADMINOFADMIN')
						func(2);
				} else
					xhr2.onerror();
			}
			xhr2.onerror = function () {
				alert('Ошибка в логине или пароле(!).');
				location.reload()
			}
			xhr2.send();
		} else
		{
			xhr.onerror();
			location.reload()
		}
	}

	xhr.onerror = function () {
		alert('Ошибка в логине(!) или пароле.');
	}
	xhr.send();
}
