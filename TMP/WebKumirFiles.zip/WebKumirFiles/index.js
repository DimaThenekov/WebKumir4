const VERSION = "4_000";

const {Worker, workerData, parentPort} = require('worker_threads');
const fs = require('fs');
const crypto = require('crypto');
const path = require('path');

const PROJECT_DIRECTORY =  __dirname;

const settings = JSON.parse(workerData);
let SERVER_PORT = settings.port;

const write = (x)=>{ parentPort.postMessage(' ' + x) };


function range(n) { return (new Array(n).fill(0).map((x,i)=>i)); }

function save_all(callback) {
	write('SAVING');
	
	if (callback) callback(); //setTimeout(callback,1000);
}

function init(callback) {
	write(`Run initialisation`);
	init_files(()=>{

		write('Run tester');
		const tester = new Worker(PROJECT_DIRECTORY+'/tester.js', { workerData: '' });
		tester.on('message', (x)=>{
			write('[Tester] '+x);
		});
		tester.on('error', (err) => { write('[Tester] '+err); process.exit(1); });
		tester.on('exit', (code) => { write('[Tester] Stopped with exit code '+code); process.exit(1); } );
		write('- read init.json');


		setTimeout(callback,1000);
	});
}


let t = 0;
function uid_gen() {
	return Math.floor(Math.random()*(16**8)).toString(16).toUpperCase().padStart(8, '0') + 
	((+new Date()) % 16**8).toString(16).toUpperCase().padStart(8, '0') +
	(++t % 16**8).toString(16).toUpperCase().padStart(8, '0');
}




function new_player(name, sha256_password){
	return {
		name: name,
		password: sha256_password,

		group: 'u',
		personage: [0, 0, 0, 0, 0, 0],

		map_data: {
			"name": {
				scores: 0,
				dollars: [],
				fine: 0,
				programs: [],
				pos_x: 0,
				pos_y: 0,
				dors: {}
			}
		}
	}
}


let all_data = ({
	players: {
		/*
		// "$" + name
		"$name": {
			name: string,
			password: string, // sha256

			group: string,
			personage: [number, number, number, number, number, number],

			map_data: {
				"uid": {
					scores: number,
					dollars: ['0;0'],
					fine: number,
					programs: [],
					pos_x: number,
					pos_y: number,
					dors: {
						'task_name': number // isAccess
					}
				}
			}
		}
		*/
		
	},
	
	
	turnirs: {
		"uid": {
			"project": "Линейные алгоритмы",
			"owner": "admin",
			"display_name": "Линейные алгоритмы",
			"freeze_data": "",
			"time_start": (+new Date())/1000 + 2,
			"time_freeze": (+new Date())/1000+60*60*2,
			"time_end": (+new Date())/1000+60*60*10,
			"group": ['u']
		},
		
		
	},
	
	// settings:
	settings_registration_enabled: true,
	
	// token - random string by uid_gen()
	// If user take correct login and password, they take token and this property get record
	token2player: {},
	
	
	
	// set true if this object was changed
	// (exception - players position)
	updated: false
});


let static_data = ({
	projects: {
		"Линейные алгоритмы": {
			folder: "01_Lineynye_algoritmy",
			tasks: [
				{
					name: "Фантастическая дорога",
					condition: "print hello",
					default_program: `Использовать Робот
алг
нач
	вправо
	вниз
	влево
	вверх
	вправо
	вниз
	влево
	вверх
	вправо
	вниз
	влево
	вверх
	вправо
	вниз
	влево
	вверх
	
кон`,
					solution: "{print('hello')}",
					tests: [
						{
							fil: `; Field Size: x, y
5 5
; Robot position: x, y
0 0
; A set of special Fields: x, y, Wall, Color, Radiation, Temperature, Symbol, Symbol1, Point
; End Of File`,
							input: '',
							expected_output: 'hello',
							is_secret: false
						},
						{
							fil: `; Field Size: x, y
5 5
; Robot position: x, y
0 0
; A set of special Fields: x, y, Wall, Color, Radiation, Temperature, Symbol, Symbol1, Point
; End Of File`,
							input: '',
							expected_output: 'hello',
							is_secret: true
						},
					]
				}
			],
			
			map: {"Ds":[{"x":14,"y":-17},{"x":-11,"y":-1},{"x":-9,"y":-1},{"x":-33,"y":0},{"x":-10,"y":0},{"x":-11,"y":1},{"x":-9,"y":1}],"RHs":[{"x1":-22,"x2":-18,"y":-9,"dor":"3"},{"x1":1,"x2":5,"y":-9,"dor":"0"},{"x1":17,"x2":21,"y":-7,"dor":"12"},{"x1":-31,"x2":-27,"y":-4,"dor":"14"},{"x1":17,"x2":21,"y":-1,"dor":"11"},{"x1":-31,"x2":-27,"y":0,"dor":"15"},{"x1":-22,"x2":-18,"y":0},{"x1":-7,"x2":-3,"y":0,"dor":"17"},{"x1":3,"x2":11,"y":0},{"x1":-31,"x2":-27,"y":4,"dor":"16"},{"x1":17,"x2":21,"y":5,"dor":"10"},{"x1":-22,"x2":-18,"y":9,"dor":"4"},{"x1":1,"x2":5,"y":9,"dor":"8"}],"RVs":[{"x":-17,"y1":-6,"y2":-1},{"x":-17,"y1":1,"y2":6},{"x":-15,"y1":-16,"y2":-12,"dor":"18"},{"x":-15,"y1":12,"y2":16,"dor":"5"},{"x":-9,"y1":-16,"y2":-12,"dor":"2"},{"x":-9,"y1":12,"y2":16,"dor":"6"},{"x":-3,"y1":-16,"y2":-12,"dor":"1"},{"x":-3,"y1":12,"y2":16,"dor":"7"},{"x":0,"y1":-6,"y2":-3},{"x":0,"y1":3,"y2":6},{"x":14,"y1":-14,"y2":-10,"dor":"13"},{"x":14,"y1":9,"y2":13,"dor":"9"}],"ROOMs":[{"x1":-16,"y1":-19,"x2":-14,"y2":-17},{"x1":-10,"y1":-19,"x2":-8,"y2":-17},{"x1":-4,"y1":-19,"x2":-2,"y2":-17},{"x1":12,"y1":-19,"x2":16,"y2":-15},{"x1":-17,"y1":-11,"x2":0,"y2":-7},{"x1":-25,"y1":-10,"x2":-23,"y2":-8},{"x1":6,"y1":-10,"x2":8,"y2":-8},{"x1":12,"y1":-9,"x2":16,"y2":8},{"x1":22,"y1":-8,"x2":24,"y2":-6},{"x1":-34,"y1":-4,"x2":-32,"y2":4},{"x1":-26,"y1":-4,"x2":-23,"y2":4},{"x1":-12,"y1":-2,"x2":-8,"y2":2},{"x1":-2,"y1":-2,"x2":2,"y2":2},{"x1":22,"y1":-2,"x2":24,"y2":0},{"x1":-17,"y1":0,"x2":-17,"y2":0},{"x1":22,"y1":4,"x2":24,"y2":6},{"x1":-17,"y1":7,"x2":0,"y2":11},{"x1":-25,"y1":8,"x2":-23,"y2":10},{"x1":6,"y1":8,"x2":8,"y2":10},{"x1":13,"y1":14,"x2":15,"y2":16},{"x1":-16,"y1":17,"x2":-14,"y2":19},{"x1":-10,"y1":17,"x2":-8,"y2":19},{"x1":-4,"y1":17,"x2":-2,"y2":19}]}
		}
	},
	
	
	// group
	group2permissions: {
		'': ['MAIN'],
		'u': ['MAIN', 'USER'],
		'a': ['MAIN', 'USER', 'ADMIN'],
		//'admin': Object.keys(api_request_map).map(x=>x.includes('_permission')?api_request_map[x]:'').filter(x=>x)
	},
	
	
	$testing_function: ()=>{},
	
	// files from tasks
	files: {
		'': ''
	},
	
	// set true if this object was changed
	// (exception - players position)
	updated: false
});

// ======================= API =======================
// ======================= API =======================
// ======================= API =======================

(global || window).all_data = all_data;
(global || window).static_data = static_data;
(global || window).write = write;
(global || window).g_sha256 = (s)=>{return crypto.createHash('sha256').update(s).digest('hex')}
require('./api.js');
let api_request_map = (global || window).api_request_map;

// ======================= API =======================
// ======================= API =======================
// ======================= API =======================



function init_files(callback) {
	if (settings.admin_login && typeof settings.admin_login == 'string' && settings.admin_password && typeof settings.admin_password == 'string') {
		all_data.players['$'+settings.admin_login] = new_player(settings.admin_login, crypto.createHash('sha256').update(settings.admin_password).digest('hex'));
	} else {
		write('Error with settings.admin_login/settings.admin_password');
		process.exit(1);
	}
	//console.log(all_data);
	
	callback();
}






function RAPI(obj, callback) {
	try {
		if (!(obj.command && typeof obj.command == 'string'))
			callback({error:'obj.command is undefined!'});
		
		else if (!api_request_map[obj.command] || !api_request_map[obj.command+'_permission'])
			callback({error:'Command "'+obj.command+'" is undefined!'});
		
		else if (obj.data===undefined)
			callback({error:'obj.data is undefined!'});
		
		else if (typeof obj.token == 'string' && obj.token && !all_data.token2player[obj.token]) {
			callback({error:'Token expired!'});
			
		} else if (typeof obj.token == 'string' && obj.token && all_data.token2player[obj.token]) {
			const name = all_data.token2player[obj.token];
			const player = all_data.players['$' + name];
			const permissions = static_data.group2permissions[player.group];
			
			player.req = {token: obj.token, turnir: obj.turnir}
			
			if (permissions.includes(api_request_map[obj.command+'_permission']))
				api_request_map[obj.command](player, obj.data, (v)=>callback({error:'', data:v}), (v)=>typeof v == "string"?callback({error:v, apiError: true}):callback({error:JSON.stringify(v), apiError: true}));
			else
				callback({error:'Access Denied!'});
			
			player.req = null;
		} else {
			if (['MAIN'].includes(api_request_map[obj.command+'_permission']))
				api_request_map[obj.command](null, obj.data, (v)=>callback({error:'', data:v}), (v)=>typeof v == "string"?callback({error:v}):callback({error:JSON.stringify(v)}));
			else
				callback({error:'Access Denied!'});
		}
	} catch(e) {
		callback({error:'Error: '+e});
	}
	// callback({error:'', data: []});
	// console.log(obj);
}













parentPort.on('message', (message) => {
	//write('message: '+message);
	if (message=='close')  return save_all(()=>{write('$end_close');process.exit(1);});
});


//console.log(PROJECT_DIRECTORY);


const http = require('http');
const MAX_CONTENT_LENGTH = 64000000;
const wr = (res, code, message)=>{res.writeHead(code || 500).end(message||undefined);}
const err_json = (message, uid)=>{return JSON.stringify({message, uid})}

const server = http.createServer((req, res) => {
	const startTime = new Date();
	let uid;
	try {
		if (!req.url.startsWith('/'))
			return wr(res,400, err_json('', uid));
		
		if (req.headers['Content-Length'] > MAX_CONTENT_LENGTH)
			return wr(res, 400, err_json('Big content-length', uid));
		
		// POST handling
		if (req.method === 'POST') {
			return getBody(req, res, (body)=>{
			
				const rawBody = body.toString('utf8');
				if (rawBody.length > 32000) {
					return wr(res, 500, err_json('Big data', uid));
				}
				let t;
				try {
					t = JSON.parse(rawBody);
					if (!(typeof t === 'object' && !Array.isArray(t) && t !== null))
						return wr(res, 400, err_json('JSON is not object', uid));
					if (t.uid && typeof t.uid === 'string')
						uid = t.uid;
				} catch (e) { return wr(res, 400, err_json('JSON is not valid', uid)); }
				
				return RAPI(t, (x)=>{
					x.uid = uid;
					wr(res, 200, JSON.stringify(x));
				});
			});
		}
		

		// Redirect root requests
		if (['/', '', '\\'].includes(req.url)) {
		  return res.writeHead(301, {"Location": "/login.html"}).end();
		}
		
		// Static file serving
		// Resolve file path safely
		const filePath = path.join(PROJECT_DIRECTORY, 'index', ...req.url.split('?')[0].split('/'));
		
		// Check if file exists
		if (!fs.lstatSync(filePath).isFile()) {
			return wr(res, 404, '404');
		}
		
		const ext = path.extname(filePath).toLowerCase();
		const mimeTypes = {
			'.pdf': 'application/pdf',
			'.mp4': 'video/mp4',
			'.avi': 'video/x-msvideo',
			'.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
			'.mp3': 'audio/mpeg',
			'.ico': 'image/x-icon',
			'.gif': 'image/gif',
			'.jpg': 'image/jpeg',
			'.jpeg': 'image/jpeg',
			'.bmp': 'image/bmp',
			'.png': 'image/png',
			'.css': 'text/css',
			'.kum': 'text/plain',
		};

		// Set Content-Type header
		res.setHeader('Content-Type', mimeTypes[ext] || 'text/html');

		// PDF handling
		if (ext === '.pdf') {
			res.setHeader('Content-Disposition', `inline; filename="${path.basename(filePath)}"`);
			const stream = fs.createReadStream(filePath);
			stream.pipe(res);
			return;
		}

		// Video handling (MP4/AVI)
		if (ext === '.mp4' || ext === '.avi') {
			const range = req.headers.range;
			if (!range) {
				const stream = fs.createReadStream(filePath);
				stream.pipe(res);
				return;
			}

			fs.stat(filePath, (err, stats) => {
				if (err) return wr(res, 500, 'Internal Server Error');
				
				const videoSize = stats.size;
				const CHUNK_SIZE = 10 ** 6; // 1MB
				const start = parseInt(range.replace(/\D/g, ''));
				const end = Math.min(start + CHUNK_SIZE, videoSize - 1);
				const contentLength = end - start + 1;

				res.writeHead(206, {
					'Content-Range': `bytes ${start}-${end}/${videoSize}`,
					'Accept-Ranges': 'bytes',
					'Content-Length': contentLength
				});

				const videoStream = fs.createReadStream(filePath, { start, end });
				videoStream.pipe(res);
			});
			return;
		}

		// Text-based files
		if (['.css', '.txt', '.html', '.htm', '.js', '.xml', '.kum'].includes(ext)) {
			const stream = fs.createReadStream(filePath);
			stream.pipe(res);
			return;
		}

		// Default file handling
		const stream = fs.createReadStream(filePath);
		stream.pipe(res);
	} catch (error) {
		console.error('Request error:', error);
		wr(res,500, err_json('Server error', uid));
	} finally {
		const duration = new Date() - startTime;
		console.log(`Request to ${req.url} took ${duration}ms`);
		// Add to metrics queue (tps_que implementation would go here)
	}
});


function getBody(request, res, cb) {
	const bodyParts = [];

	request.on('error', (error) => {
		console.log(error);
		return wr(res, 400, 'POST error');
	})
	
	request.on('data', (chunk) => {
		bodyParts.push(chunk);
	})
	
	request.on('end', () => {
		const body = Buffer.concat(bodyParts).toString();
		cb(body);
	});
}

server.on('error', (error) => {
	if (error.code === 'EADDRINUSE') {
		write(`Port ${SERVER_PORT} already in use`);
		SERVER_PORT = SERVER_PORT - 1
		write(`Trying to restart the service on port ${SERVER_PORT}... `);
		if (SERVER_PORT !== 0) {
			setTimeout(() => server.listen(SERVER_PORT), 1000)
		} else {
			process.exit(1);
		}
	} else throw error;
});

// WebSocket upgrade handler
server.on('upgrade', (req, socket) => {
	// Validate handshake
	if (req.headers['upgrade'] !== 'websocket') {
		socket.end('HTTP/1.1 400 Bad Request');
		return;
	}
	
	// Compute accept key
	const acceptKey = crypto
		.createHash('sha1')
		.update(req.headers['sec-websocket-key'] + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11')
		.digest('base64');

	// Write upgrade response
	const headers = [
		'HTTP/1.1 101 Switching Protocols',
		'Upgrade: websocket',
		'Connection: Upgrade',
		`Sec-WebSocket-Accept: ${acceptKey}`
	];
	socket.write(headers.join('\r\n') + '\r\n\r\n');


	socket.buffer = Buffer.alloc(0);
	socket.frameState = {};

	socket.on('data', (chunk) => {
		// Append new data to buffer
		socket.buffer = Buffer.concat([socket.buffer, chunk]);
		
		// Process all complete frames in buffer
		while (socket.buffer.length > 0) {
			const result = parseFrame(socket.buffer, socket.frameState);
		
			if (result === null) {
				// Incomplete frame, wait for more data
				break;
			}
			
			const { frame, bytesConsumed } = result;
			// Remove processed data from buffer
			socket.buffer = socket.buffer.subarray(bytesConsumed);
			
			// Reset frame state after successful parse
			socket.frameState = {};
			
			// Handle frame
			if (frame.opcode === 1) {  // Text frame
				(()=>{
					const message = frame.payload.toString('utf8');
					console.log(message);
					let uid;
					if (message.length > 32000) {
						return sendText(socket, err_json('Big data', uid));
					}
					let t;
					try {
						t = JSON.parse(message);
						if (!(typeof t === 'object' && !Array.isArray(t) && t !== null))
							return sendText(socket, err_json('JSON is not object', uid));
						if (t.uid && typeof t.uid === 'string')
							uid = t.uid;
					} catch (e) { return sendText(socket, err_json('JSON is not valid', uid)); }
					
					return RAPI(t, (x)=>{
						x.uid = uid;
						sendText(socket, JSON.stringify(x));
					});
				})();
			} else if (frame.opcode === 8) {  // Close frame
				socket.end();
				break;
			} else if (frame.opcode === 9) {  // Ping frame
				sendPong(socket, frame.payload || {});
			}
		}
	});
});

// Frame parser
function parseFrame(buffer, state) {
	// Initialize state on first call
	state.offset = state.offset || 0;
	
	// Minimum header size is 2 bytes
	if (buffer.length - state.offset < 2) return null;

	const byte1 = buffer.readUInt8(state.offset);
	const byte2 = buffer.readUInt8(state.offset + 1);
	
	// Only process if we have FIN bit set (simple implementation)
	if (!state.fin) {
		state.fin = (byte1 & 0x80) !== 0;
		state.opcode = byte1 & 0x0f;
		state.isMasked = (byte2 & 0x80) !== 0;
		state.payloadLength = byte2 & 0x7f;
		state.offset += 2;

		// Handle extended payload length
		if (state.payloadLength === 126) {
			if (buffer.length - state.offset < 2) return null;
			state.payloadLength = buffer.readUInt16BE(state.offset);
			state.offset += 2;
		} else if (state.payloadLength === 127) {
			if (buffer.length - state.offset < 8) return null;
			state.payloadLength = Number(buffer.readBigUInt64BE(state.offset));
			state.offset += 8;
		}

		// Get masking key
		if (state.isMasked) {
			if (buffer.length - state.offset < 4) return null;
			state.maskingKey = buffer.subarray(state.offset, state.offset + 4);
			state.offset += 4;
		}
	}

	// Check if we have complete payload
	const totalFrameSize = state.offset + state.payloadLength;
	if (buffer.length < totalFrameSize) return null;

	// Extract payload
	const payload = buffer.subarray(state.offset, totalFrameSize);
	state.offset = totalFrameSize;

	// Unmask payload
	if (state.isMasked && state.maskingKey) {
		for (let i = 0; i < payload.length; i++) {
			payload[i] ^= state.maskingKey[i % 4];
		}
	}

	return {
		frame: {
			opcode: state.opcode,
			payload: payload
		},
		bytesConsumed: totalFrameSize
	};
}

// Send Pong frame
function sendPong(socket, payload) {
	const frame = Buffer.alloc(2 + (payload.length || 0));
	frame.writeUInt8(0x8A, 0); // FIN + Pong opcode
	frame.writeUInt8(payload.length || 0, 1);
	if (payload) payload.copy(frame, 2);
	socket.write(frame);
}


// Send text frame
function sendText(socket, message) {
	const payload = Buffer.from(message, 'utf8');
	const payloadLength = payload.length;
	let headerLength = 2;  // Base header size
	let extraLengthBytes = 0;

	// Determine required payload length bytes
	if (payloadLength <= 125) {
		extraLengthBytes = 0;
	} else if (payloadLength <= 65535) {
		extraLengthBytes = 2;
		headerLength += extraLengthBytes;
	} else {
		extraLengthBytes = 8;
		headerLength += extraLengthBytes;
	}

	// Create frame buffer
	const frame = Buffer.alloc(headerLength + payloadLength);
	
	// Set FIN bit (0x80) and text opcode (0x01)
	frame.writeUInt8(0x81, 0);  // 0x81 = FIN + text frame
	
	// Write payload length and extended length
	let offset = 1;
	if (payloadLength <= 125) {
		frame.writeUInt8(payloadLength, offset++);
	} else if (payloadLength <= 65535) {
		frame.writeUInt8(126, offset++);
		frame.writeUInt16BE(payloadLength, offset);
		offset += 2;
	} else {
		frame.writeUInt8(127, offset++);
		frame.writeBigUInt64BE(BigInt(payloadLength), offset);
		offset += 8;
	}

	// Copy payload into frame
	payload.copy(frame, offset);
	
	socket.write(frame);
}

init(()=>{
	server.listen(SERVER_PORT, ()=>{
		write(`WebKumir v${VERSION} running at http://localhost:${SERVER_PORT}`);
		parentPort.postMessage('$run');
	});
});