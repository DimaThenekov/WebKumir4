var all_data = (global || window).all_data;
var static_data = (global || window).static_data;
var api_request_map={};
var g_sha256 = (global || window).g_sha256;
var write = (global || window).write;
if (!g_sha256) g_sha256 = (s)=>MD5?MD5(s):'___'+s+'___';

let ___t = 0;
function uid_gen() {
	return Math.floor(Math.random()*(16**8)).toString(16).toUpperCase().padStart(8, '0') + 
	((+new Date()) % 16**8).toString(16).toUpperCase().padStart(8, '0') +
	(++___t % 16**8).toString(16).toUpperCase().padStart(8, '0');
}

function test_programm(programm, test) {
	let g = (global || window);
	if (!g.RunKumir_try){
		eval(require('fs').readFileSync(__dirname+'\\index\\js\\kumir.js', "utf8"));
		g.RunKumir_try = RunKumir_try;
		g.GetErrorKumir = ()=>ErrorKumir;
	}
	
	if (!g.RunKumir_try){ write('Функция RunKumir_try не определена'); process.exit(1); }
	g.RunKumir_try('');
	if (g.GetErrorKumir().length<1){ write('Функция RunKumir_try не верно работает'); process.exit(1); }
	
	return test.map((x,i)=>{
			//console.log(programm, JSON.stringify(x));
			g.RunKumir_try(programm, JSON.stringify(x));
			return { test_number: i, errors: g.GetErrorKumir() };
		}).filter(x=>x.errors.length);
}


/*
	all_data ~= ({
		players: {
			// "$" + name
			"$name": {
				name: string,
				password: string, // sha256

				group: string,
				personage: [number, number, number, number, number, number],

				map_data: {
					"uid": {
						scores: number,
						dollars: ['0;0'],
						fine: number,
						programs: [],
						pos_x: number,
						pos_y: number,
						dors: {
							'0;0': number // isAccess
						}
					}
				}
			}
		},
		
		
		turnirs: {
			"uid": {
				"project": "Линейные алгоритмы",
				"owner": "admin",
				"display_name": "Линейные алгоритмы",
				"string_freeze": "",
				"time_start": 1640984400,
				"time_freeze": 1956340800,
				"time_end": 1956344400,
				"group": ['']
			},
			
			
		},
		
		
		projects: {
			"Линейные алгоритмы": {
				folder: "01_Lineynye_algoritmy"
			}
		},
		
		// settings:
		settings_registration_enabled: false,
		
		// token - random string by uid_gen()
		// If user take correct login and password, they take token and this property get record
		token2player: {},
		
		// group
		group2permissions: {
			'': ['MAIN'],
			//'admin': Object.keys(api_request_map).map(x=>x.includes('_permission')?api_request_map[x]:'').filter(x=>x)
		},
		
		// files from tasks
		files: {
			'': ''
		},
		
		// set true if this object was changed
		updated: false
	});
*/

api_request_map['is_registration_enabled_permission'] = 'MAIN';
api_request_map['is_registration_enabled'] = (_user, _data, resolve, _reject) => {
	resolve(all_data.settings_registration_enabled);
};

api_request_map['login_permission'] = 'MAIN';
api_request_map['login'] = (_user, data, resolve, reject) => {
	const { name, password } = data;
	if (all_data.players['$'+name] &&
		all_data.players['$'+name].name == name &&
		all_data.players['$'+name].password == g_sha256(password)) {
		const token = uid_gen();
		all_data.token2player[token] = name;
		all_data.updated = true;
		resolve(token);
	} else {
		reject('Name or password is incorrect!');
	}
};





function user_have_permission_for_turnir(user, turnir, use_time_end) {
	var now = Date.now() / 1000;
	
	var groupOk = turnir.group.length === 0 || 
			turnir.group.indexOf(user.group) !== -1;

	var status = "OK";
	if (!groupOk) return false;
	else if (use_time_end && now > turnir.time_end) return false;
	
	return true;
}

function user_get_turnir_map_data(user, turnir_uid) {
	if (!user.map_data[turnir_uid]) {
		user.map_data[turnir_uid] = {
			scores: 0,
			dollars: ['0;0'],
			fine: 0,
			programs: [],
			pos_x: 0,
			pos_y: 0,
			dors: {}
		};
	}
	return user.map_data[turnir_uid];
}




api_request_map['ping_permission'] = 'USER';
api_request_map['ping'] = (user, _data, resolve, _reject) => {
	resolve('pong');
}


api_request_map['server_list_permission'] = 'USER';
api_request_map['server_list'] = (user, _data, resolve, _reject) => {
	var result = [];
	var now = Date.now() / 1000; // Текущее время в секундах
	
	for (var uid in all_data.turnirs) {
		if (all_data.turnirs.hasOwnProperty(uid)) {
			var turnir = all_data.turnirs[uid];
			var groupOk = turnir.group.length === 0 || 
					turnir.group.indexOf(user.group) !== -1;
		
			var status = "OK";
			if (!groupOk) continue; // ?
			else if (now < turnir.time_start) status = "NOT STARTED";
			else if (now > turnir.time_end) status = "END";
			
			result.push({
				uid: uid,
				name: turnir.display_name,
				status: status,
				time_start: turnir.time_start,
				time_start_diff: turnir.time_start*1000-(Date.now()),
				duration: turnir.time_end - turnir.time_start
			});
		}
	}
	resolve(result);
}

function task_solved(map_data, task_name) {
	return map_data.programs.filter(x=>x.task_name == task_name && x.value == 1).length;
}
function isPointOnMap(map_data, map, x, y) {
	
	function isInRoom(room) {
		return x >= room.x1 && x <= room.x2 && y >= room.y1 && y <= room.y2;
	}

	function isOnHorizontalRoad(road) {
		if (typeof road.dor == 'string' && road.dor.startsWith('task:')) {
			const mid = Math.floor((road.x1 + road.x2)/2);
			if (Math.abs(x - mid) <= 1) {
				const task = road.dor.slice(5);
				if (!map_data.dors[task])
					map_data.dors[task] = 1;
				if (map_data.dors[task]<2) {
					if (task_solved(map_data, task)) map_data.dors[task] = 2;
					else if (x == mid) return false;
				}
			}
		}
		return y === road.y && x >= road.x1 && x <= road.x2;
	}

	function isOnVerticalRoad(road) {
		if (typeof road.dor == 'string' && road.dor.startsWith('task:')) {
			const mid = Math.floor((road.y1 + road.y2)/2);
			if (Math.abs(y - mid) <= 1) {
				const task = road.dor.slice(5);
				if (!map_data.dors[task])
					map_data.dors[task] = 1;
				if (map_data.dors[task]<2) {
					if (task_solved(map_data, task)) map_data.dors[task] = 2;
					else if (x == mid) return false;
				}
			}
		}
		return x === road.x && y >= road.y1 && y <= road.y2;
	}

	for (const room of map.ROOMs) {
		if (isInRoom(room)) {
			return true;
		}
	}

	for (const road of map.RHs) {
		if (isOnHorizontalRoad(road)) {
			return true;
		}
	}

	for (const road of map.RVs) {
		if (isOnVerticalRoad(road)) {
			return true;
		}
	}
	
	return false;
}



api_request_map['get_is_access_permission'] = 'USER';
api_request_map['get_is_access'] = (user, data, resolve, _reject) => {
	const { project_uid } = data;
	
	// TODO validation logic
	
	const accesses = user.map_data[project_uid].dors;
	resolve(JSON.stringify(Object.keys(accesses)));
};


api_request_map['get_prog_list_permission'] = 'USER';
api_request_map['get_prog_list'] = (user, _data, resolve, _reject) => {
	// ... (admin-only project/task list generation)
	resolve(projectListJson);
};

api_request_map['get_time_permission'] = 'USER';
api_request_map['get_time'] = (user, data, resolve, _reject) => {
	const project_uid = data;
	
	// TODO validation logic
	
	const project = all_data.turnirs[project_uid];
	const currentTime = Math.floor(Date.now() / 1000);
	const delta = project.time_end - currentTime;
	resolve([currentTime, delta]);
};

api_request_map['edit_personage_permission'] = 'USER';
api_request_map['edit_personage'] = (user, data, resolve, _reject) => {
	const [p1, p2, p3, p4, p5, p6] = data;
	
	// TODO validation logic
	
	user.personage = [p1, p2, p3, p4, p5, p6];
	resolve('OK');
};


api_request_map['get_map_permission'] = 'USER';
api_request_map['get_map'] = (user, data, resolve, reject) => {
	
	const turnir_uid = user.req.turnir;
	if (!turnir_uid) return reject("turnir_uid == false");
	
	const turnir = all_data.turnirs[turnir_uid];
	if (!turnir) return reject("Turnir not found");
	if (!user_have_permission_for_turnir(user, turnir)) return reject("403");
	const user_map_data = user_get_turnir_map_data(user, turnir_uid);
	
	const project = static_data.projects[turnir.project];
	if (!project) return reject("Project not found");
	
	const map = project.map;
	if (!map) return reject("map not found");
	
	const nRVs = [];
	for (const road of map.RVs) {
		let solved = false;
		if (typeof road.dor == 'string' && road.dor.startsWith('task:')) {
			const task = road.dor.slice(5);
			if (user_map_data.dors[task]) {
				if (user_map_data.dors[task]==2) solved = true; // optimisation
				else if (task_solved(user_map_data, task)) solved = true;
			}
		}
		if (solved)
			nRVs.push({ ...road, dor: road.dor.replace('task:', 'solved_task:') });
		else
			nRVs.push(road);
	}
	
	const nRHs = [];
	for (const road of map.RHs) {
		let solved = false;
		if (typeof road.dor == 'string' && road.dor.startsWith('task:')) {
			const task = road.dor.slice(5);
			if (user_map_data.dors[task]) {
				if (user_map_data.dors[task]==2) solved = true; // optimisation
				else if (task_solved(user_map_data, task)) solved = true;
			}
		}
		console.log(solved);
		console.log(road);
		//console.log(road.dor.replace('task:', 'solved_task:'));
		if (solved)
			nRHs.push({ ...road, dor: road.dor.replace('task:', 'solved_task:') });
		else
			nRHs.push(road);
	}
	
	resolve({ ...map, RHs: nRHs, RVs: nRVs});
};


api_request_map['get_positions_permission'] = 'USER';
api_request_map['get_positions'] = (user, data, resolve, reject) => {
	
	const turnir_uid = user.req.turnir;
	if (!turnir_uid) return reject("turnir_uid == false");
	
	const turnir = all_data.turnirs[turnir_uid];
	if (!turnir) return reject("Turnir not found");
	if (!user_have_permission_for_turnir(user, turnir)) return reject("403");
	const user_map_data = user_get_turnir_map_data(user, turnir_uid);
	
	resolve(Object.values(all_data.players).map(x=>[x,x.map_data[turnir_uid]]).filter(x=>x[1]).map(x=>({
		name: x[0].name,
		is_current_user: user==x[0],
		pos_x: x[1].pos_x,
		pos_y: x[1].pos_y,
		personage: x[0].personage
	})));
};


api_request_map['move_permission'] = 'USER';
api_request_map['move'] = (user, data, resolve, reject) => {
	const turnir_uid = user.req.turnir;
	if (!turnir_uid) return reject("turnir_uid == false");
	
	const turnir = all_data.turnirs[turnir_uid];
	if (!turnir) return reject("Turnir not found");
	if (!user_have_permission_for_turnir(user, turnir)) return reject("403");
	const user_map_data = user_get_turnir_map_data(user, turnir_uid);
	
	const project = static_data.projects[turnir.project];
	if (!project) return reject("Project not found");
	
	const map = project.map;
	if (!map) return reject("map not found");
	
	let x = user_map_data.pos_x;
	let y = user_map_data.pos_y;
	
	x+={left:-1, right:1}[data]||0;
	y+={up:-1, down:1}[data]||0;
	
	if (isPointOnMap(user_map_data, map, x, y)) {
		user_map_data.pos_x = x;
		user_map_data.pos_y = y;
		
		return resolve(true);
	}
	return resolve(false);
	
};

api_request_map['get_programs_permission'] = 'USER';
api_request_map['get_programs'] = (user, data, resolve, reject) => {
	const task_name = data;
	
	const turnir_uid = user.req.turnir;
	if (!turnir_uid) return reject("turnir_uid == false");
	
	const turnir = all_data.turnirs[turnir_uid];
	if (!turnir) return reject("Turnir not found");
	if (!user_have_permission_for_turnir(user, turnir)) return reject("403 - turnir access");
	
	const user_map_data = user_get_turnir_map_data(user, turnir_uid);
	if (!user_map_data.dors[task_name])  return reject("403 - task access");
	
	resolve(user_map_data.programs.filter(x=>x.task_name == task_name).map((x,i)=>({
		N: i+1,
		send_time: x.send_time,
		programm: x.programm,
		value: x.value
	})).sort((x,y)=>y.send_time-x.send_time))
	
}
api_request_map['get_task_permission'] = 'USER';
api_request_map['get_task'] = (user, data, resolve, reject) => {
	const task_name = data;
	
	const turnir_uid = user.req.turnir;
	if (!turnir_uid) return reject("turnir_uid == false");
	
	const turnir = all_data.turnirs[turnir_uid];
	if (!turnir) return reject("Turnir not found");
	if (!user_have_permission_for_turnir(user, turnir)) return reject("403 - turnir access");
	
	const user_map_data = user_get_turnir_map_data(user, turnir_uid);
	if (!user_map_data.dors[task_name])  return reject("403 - task access");
	
	const project = static_data.projects[turnir.project];
	if (!project) return reject("Project not found");
	
	const task = project.tasks.filter(x=>x.name == task_name)[0];
	if (!task) return reject("Task not found");
	
	const tabs = [];
	
	tabs.push({type: "text", name: "Условие", text: task.condition} );
	task.tests.map((x, i)=>{
		if (!x.is_secret)
			tabs.push({type: "fil", name: "Тест "+(i+1), value: JSON.stringify({fil: x.fil, input: x.input, expected_output: x.expected_output})});
		else
			tabs.push({type: "text", name: "Тест "+(i+1), text: '<i>~Засекреченый тест~</i>'});
	});
	tabs.push({type: "load", name: "Отправить"});
	tabs.push({type: "site", url: '/top.html', name: "Рейтинг"});
	
	resolve({ default_program: task.default_program, tabs });
}

api_request_map['get_top_permission'] = 'USER';
api_request_map['get_top'] = (user, data, resolve, reject) => {
	const turnir_uid = user.req.turnir;
	if (!turnir_uid) return reject("turnir_uid == false");
	
	const turnir = all_data.turnirs[turnir_uid];
	if (!turnir) return reject("Turnir not found");
	if (!user_have_permission_for_turnir(user, turnir)) return reject("403 - turnir access");
	
	const user_map_data = user_get_turnir_map_data(user, turnir_uid);
	
	const project = static_data.projects[turnir.project];
	if (!project) return reject("Project not found");
	
	const task_names = project.tasks.map(x=>x.name);
	const users = Object.keys(all_data.players).map(x=>all_data.players[x]).filter(x=>x.map_data[turnir_uid]);
	
	function get_data_by_user(user_map_data) {
		let data = {score: 0, fine: 0, tasks: task_names.map(x=>0)}
		user_map_data.programs.filter(x=>x.value == 1).map(x=>{
			if (data.tasks[task_names.indexOf(x.task_name)] != 100) {
				data.tasks[task_names.indexOf(x.task_name)] = 100;
				data.fine += Math.floor((x.send_time/1000 - turnir.time_start)/10);
			}
		});
		data.score=data.tasks.reduce((x,y)=>x+y,0)+user_map_data.dollars.length;
		return data;
	}
	
	if (turnir.time_freeze<(+new Date())/1000) {
		if (!turnir.freeze_data) {
			turnir.freeze_data = {};
			
			users.map(x=>turnir.freeze_data[x.name] = get_data_by_user(x.map_data[turnir_uid]));
		}
		
		resolve({
			freeze: true,
			accesses: Object.keys(user_map_data.dors).filter(x=>user_map_data.dors[x]>0),
			task_names,
			data: { ...turnir.freeze_data, [user.name]: get_data_by_user(user_map_data)}});
	}else {
		let data = {};
		
		users.map(x=>data[x.name] = get_data_by_user(x.map_data[turnir_uid]));
		
		resolve({freeze: false,
			accesses: Object.keys(user_map_data.dors).filter(x=>user_map_data.dors[x]>0),
			task_names,
			data});
	}
}

api_request_map['send_program_permission'] = 'USER';
api_request_map['send_program'] = (user, data, resolve, reject) => {
	const task_name = data.task_name;
	const programm = data.programm;
	
	if (!task_name) return reject("task_name null");
	if (!programm) return reject("Программа пустая!");
	
	const turnir_uid = user.req.turnir;
	if (!turnir_uid) return reject("turnir_uid == false");
	
	const turnir = all_data.turnirs[turnir_uid];
	if (!turnir) return reject("Turnir not found");
	if (!user_have_permission_for_turnir(user, turnir, true)) return reject("403 - turnir access");
	
	const user_map_data = user_get_turnir_map_data(user, turnir_uid);
	if (!user_map_data.dors[task_name])  return reject("403 - task access");
	
	const project = static_data.projects[turnir.project];
	if (!project) return reject("Project not found");
	
	const task = project.tasks.filter(x=>x.name == task_name)[0];
	if (!task) return reject("Task not found");
	
	// DDOS
	if (user_map_data.programs.map(x=>x.send_time).some(x=>x>new Date()-5000)) return reject("Попробуйте ещё раз");
	if (task_solved(user_map_data, task_name)) return reject("Эта задача уже решена");
	
	let res = test_programm(programm, task.tests);
	user_map_data.programs.push({
		send_time: +new Date(),
		task_name,
		programm,
		error: res,
		value: 1 - res.length / task.tests.length
	});
	resolve('OK');
}

api_request_map['admin_edit_permission'] = 'MAIN';
api_request_map['admin_edit'] = (user, data, resolve, reject) => {
	var path = data.path;
	var method = data.method;
	var obj = (data.obj == 'all_data'? all_data:
				(data.obj == 'static_data'?static_data:null));
	
	if (method=='set') {
		var value = data.value;
		var parts = path.split(';');
		var current = obj;
		for (var i = 0; i < parts.length - 1; i++) {
			var key = parts[i];
			if (current[key] === undefined) {
				return reject('current[key] === undefined');
			} else if (
				current[key] === null || 
				(typeof current[key] !== 'object')
			) {
				return reject('current[key] === null');
			}
			current = current[key];
		}
		
		var lastKey = parts[parts.length - 1];
		if (lastKey=='-1' && Array.isArray(current))
			current[current.length] = value;
		else
			current[lastKey] = value;
		
		all_data.updated = true;
		return resolve('OK');
	} else if (method=='get') {
		if (path)
			for (var i=0, path=path.split(';'), len=path.length; i<len; i++){
				obj = obj[path[i]];
			}
		return resolve(obj);
	}
	
}
























api_request_map['get_table_permission'] = 'USER';
api_request_map['get_programs_permission'] = 'USER';
api_request_map['get_dors_permission'] = 'USER';
api_request_map['gettab_permission'] = 'USER';
api_request_map['getpos_permission'] = 'USER';
api_request_map['get_my_programs_permission'] = 'MAIN';
api_request_map['get_my_program_permission'] = 'MAIN';
api_request_map['admin_server_list_permission'] = 'ADMIN';
api_request_map['proj_list_permission'] = 'ADMIN';
api_request_map['del_proj_permission'] = 'ADMIN';
api_request_map['get_top_proj_permission'] = 'ADMIN';
api_request_map['get_stat_players_permission'] = 'ADMIN';
api_request_map['get_players_no_group_permission'] = 'ADMIN';
api_request_map['get_players_in_group_permission'] = 'ADMIN';
api_request_map['player_add_group_permission'] = 'ADMIN';
api_request_map['player_del_group_permission'] = 'ADMIN';

// Similar pattern for other admin commands...




/*
split this monolit on pascal on my api_request_map object functions:


function LoadServFile(user, s: string; PrjInd: longint): String;
var
  i, j, k, f: longint;
  s2: string;
  userindex: longint;
begin
  userindex := GetIndex(user);
  Result := '___NoT_FoUnD_CoMmAnD__' + s + '___NoT_FoUnD_CoMmAnD__';
  if (s = 'login') then
  begin
	if not(Players[userindex].isAdmin) then
	  Result := 'OK'
	else
	  Result := 'OKADMIN';
  end
  else if (s = 'map') and (PrjInd >= 0) then
  begin
	// Result := LoadFileToStr(ExtractFilePath(ParamStr(0)) + LoadDirectory + '\save\map.txt')
	Result := '{' + #13#10 + '  "rooms": [' + #13#10;
	for i := 0 to High(Projects[RunProjects[PrjInd].parentInd].map.ROOMs) do
	begin
	  Result := Result + '    {' + #13#10;
	  Result := Result + '      "position": [' + Projects[RunProjects[PrjInd].parentInd].map.ROOMs[i][0].ToString + ',' + Projects[RunProjects[PrjInd].parentInd].map.ROOMs[i][1].ToString + ',' +
		Projects[RunProjects[PrjInd].parentInd].map.ROOMs[i][2].ToString + ',' + Projects[RunProjects[PrjInd].parentInd].map.ROOMs[i][3].ToString + ']' + #13#10;

	  if i = High(Projects[RunProjects[PrjInd].parentInd].map.ROOMs) then
		Result := Result + '    }' + #13#10
	  else
		Result := Result + '    },' + #13#10;
	end;
	// ===================================
	Result := Result + '  ],' + #13#10;
	Result := Result + '  "road vertical": [' + #13#10;
	for i := 0 to High(Projects[RunProjects[PrjInd].parentInd].map.RVs) do
	begin
	  Result := Result + '    {' + #13#10;
	  Result := Result + '      "position": [' + Projects[RunProjects[PrjInd].parentInd].map.RVs[i].pos[0].ToString + ',' + Projects[RunProjects[PrjInd].parentInd].map.RVs[i].pos[1].ToString + ',' +
		Projects[RunProjects[PrjInd].parentInd].map.RVs[i].pos[2].ToString + '],' + #13#10;
	  if ((Projects[RunProjects[PrjInd].parentInd].map.RVs[i].task = '') or (Projects[RunProjects[PrjInd].parentInd].map.RVs[i].task = 'open')) then
		Result := Result + '      "dor": "' + Projects[RunProjects[PrjInd].parentInd].map.RVs[i].task + '"' + #13#10
	  else if DorIsOpen(Players[userindex], PrjInd, Projects[RunProjects[PrjInd].parentInd].map.RVs[i].task) then
		Result := Result + '      "dor": "open"' + #13#10
	  else
		Result := Result + '      "dor": "file:' + Projects[RunProjects[PrjInd].parentInd].map.RVs[i].task + '"' + #13#10;

	  if i = High(Projects[RunProjects[PrjInd].parentInd].map.RVs) then
		Result := Result + '    }' + #13#10
	  else
		Result := Result + '    },' + #13#10;
	end;
	Result := Result + '  ],' + #13#10;
	// ===================================
	Result := Result + '  "road horizontal": [' + #13#10;
	for i := 0 to High(Projects[RunProjects[PrjInd].parentInd].map.RHs) do
	begin
	  Result := Result + '    {' + #13#10;
	  Result := Result + '      "position": [' + Projects[RunProjects[PrjInd].parentInd].map.RHs[i].pos[0].ToString + ',' + Projects[RunProjects[PrjInd].parentInd].map.RHs[i].pos[1].ToString + ',' +
		Projects[RunProjects[PrjInd].parentInd].map.RHs[i].pos[2].ToString + '],' + #13#10;
	  if ((Projects[RunProjects[PrjInd].parentInd].map.RHs[i].task = '') or (Projects[RunProjects[PrjInd].parentInd].map.RHs[i].task = 'open')) then
		Result := Result + '      "dor": "' + Projects[RunProjects[PrjInd].parentInd].map.RHs[i].task + '"' + #13#10
	  else if DorIsOpen(Players[userindex], PrjInd, Projects[RunProjects[PrjInd].parentInd].map.RHs[i].task) then
		Result := Result + '      "dor": "open"' + #13#10
	  else
		Result := Result + '      "dor": "file:' + Projects[RunProjects[PrjInd].parentInd].map.RHs[i].task + '"' + #13#10;

	  if i = High(Projects[RunProjects[PrjInd].parentInd].map.RHs) then
		Result := Result + '    }' + #13#10
	  else
		Result := Result + '    },' + #13#10;
	end;
	Result := Result + '  ],' + #13#10;
	// ===================================
	Result := Result + '  "dollar": [' + #13#10;
	for i := 0 to High(Projects[RunProjects[PrjInd].parentInd].map.Ds) do
	begin
	  Result := Result + '    {' + #13#10;

	  f := 0;
	  for j := 0 to High(Players) do
		for k := 0 to High(Players[j].dollars) do
		  if (RunProjects[PrjInd].uniID = Players[j].dollars[k].uniID) and (Players[j].dollars[k].pos = i) then
		  begin
			f := 1;
		  end;
	  if f = 0 then
	  begin
		Result := Result + '      "position": [' + Projects[RunProjects[PrjInd].parentInd].map.Ds[i][0].ToString + ',' + Projects[RunProjects[PrjInd].parentInd].map.Ds[i][1].ToString + ']' + #13#10;
	  end;
	  if i = High(Projects[RunProjects[PrjInd].parentInd].map.Ds) then
		Result := Result + '    }' + #13#10
	  else
		Result := Result + '    },' + #13#10;
	end;
	Result := Result + '  ]' + #13#10;
	// ===================================
	Result := Result + '}';
  end
  else if (s = 'move_down') and (PrjInd >= 0) then
  begin
	for j := 0 to High(Players[userindex].pos) do
	  if Players[userindex].pos[j].uniID = RunProjects[PrjInd].uniID then
	  begin
		Result := 'OK';
		GetDollar(Players[userindex].pos[j].posx, Players[userindex].pos[j].posy + 1, user, PrjInd);
		OpenAccess(Players[userindex].pos[j].posx + 1, Players[userindex].pos[j].posy + 1, user, PrjInd);
		OpenAccess(Players[userindex].pos[j].posx - 1, Players[userindex].pos[j].posy + 1, user, PrjInd);
		OpenAccess(Players[userindex].pos[j].posx, Players[userindex].pos[j].posy + 1 + 1, user, PrjInd);
		OpenAccess(Players[userindex].pos[j].posx, Players[userindex].pos[j].posy + 1 - 1, user, PrjInd);
		OpenAccess(Players[userindex].pos[j].posx, Players[userindex].pos[j].posy + 1, user, PrjInd);
		if InHouse(Players[userindex].pos[j].posx, Players[userindex].pos[j].posy + 1, user, PrjInd) then
		  inc(Players[userindex].pos[j].posy)
		else
		  Result := 'STOP';
	  end;

  end
  else if (s = 'move_left') and (PrjInd >= 0) then
  begin
	for j := 0 to High(Players[userindex].pos) do
	  if Players[userindex].pos[j].uniID = RunProjects[PrjInd].uniID then
	  begin
		Result := 'OK';
		GetDollar(Players[userindex].pos[j].posx - 1, Players[userindex].pos[j].posy, user, PrjInd);
		OpenAccess(Players[userindex].pos[j].posx - 1 + 1, Players[userindex].pos[j].posy, user, PrjInd);
		OpenAccess(Players[userindex].pos[j].posx - 1 - 1, Players[userindex].pos[j].posy, user, PrjInd);
		OpenAccess(Players[userindex].pos[j].posx - 1, Players[userindex].pos[j].posy + 1, user, PrjInd);
		OpenAccess(Players[userindex].pos[j].posx - 1, Players[userindex].pos[j].posy - 1, user, PrjInd);
		OpenAccess(Players[userindex].pos[j].posx - 1, Players[userindex].pos[j].posy, user, PrjInd);
		if InHouse(Players[userindex].pos[j].posx - 1, Players[userindex].pos[j].posy, user, PrjInd) then
		  inc(Players[userindex].pos[j].posx, -1)
		else
		  Result := 'STOP';
	  end;
  end
  else if (s = 'move_rigth') and (PrjInd >= 0) then
  begin
	for j := 0 to High(Players[userindex].pos) do
	  if Players[userindex].pos[j].uniID = RunProjects[PrjInd].uniID then
	  begin
		Result := 'OK';
		GetDollar(Players[userindex].pos[j].posx + 1, Players[userindex].pos[j].posy, user, PrjInd);
		OpenAccess(Players[userindex].pos[j].posx + 1 + 1, Players[userindex].pos[j].posy, user, PrjInd);
		OpenAccess(Players[userindex].pos[j].posx + 1 - 1, Players[userindex].pos[j].posy, user, PrjInd);
		OpenAccess(Players[userindex].pos[j].posx + 1, Players[userindex].pos[j].posy + 1, user, PrjInd);
		OpenAccess(Players[userindex].pos[j].posx + 1, Players[userindex].pos[j].posy - 1, user, PrjInd);
		OpenAccess(Players[userindex].pos[j].posx + 1, Players[userindex].pos[j].posy, user, PrjInd);
		if InHouse(Players[userindex].pos[j].posx + 1, Players[userindex].pos[j].posy, user, PrjInd) then
		  inc(Players[userindex].pos[j].posx)
		else
		  Result := 'STOP';
	  end;
  end
  else if (s = 'move_up') and (PrjInd >= 0) then
  begin
	for j := 0 to High(Players[userindex].pos) do
	  if Players[userindex].pos[j].uniID = RunProjects[PrjInd].uniID then
	  begin
		Result := 'OK';
		GetDollar(Players[userindex].pos[j].posx, Players[userindex].pos[j].posy - 1, user, PrjInd);
		OpenAccess(Players[userindex].pos[j].posx + 1, Players[userindex].pos[j].posy - 1, user, PrjInd);
		OpenAccess(Players[userindex].pos[j].posx - 1, Players[userindex].pos[j].posy - 1, user, PrjInd);
		OpenAccess(Players[userindex].pos[j].posx, Players[userindex].pos[j].posy - 1 + 1, user, PrjInd);
		OpenAccess(Players[userindex].pos[j].posx, Players[userindex].pos[j].posy - 1 - 1, user, PrjInd);
		OpenAccess(Players[userindex].pos[j].posx, Players[userindex].pos[j].posy - 1, user, PrjInd);
		if InHouse(Players[userindex].pos[j].posx, Players[userindex].pos[j].posy - 1, user, PrjInd) then
		  inc(Players[userindex].pos[j].posy, -1)
		else
		  Result := 'STOP';
	  end;
  end
  else if (s = 'get_is_access') and (PrjInd >= 0) then
  begin
	Result := '[';
	for i := 0 to High(Players[userindex].IsAccess) do
	  if Players[userindex].IsAccess[i].uniID = RunProjects[PrjInd].uniID then
		if (Players[userindex].IsAccess[i].pos mod 2 = 0) then
		begin
		  if (Players[userindex].IsAccess[i].uniID = Players[userindex].IsAccess[i].uniID) then
		  begin
			Result := Result + '"' + Projects[RunProjects[PrjInd].parentInd].map.RVs[Players[userindex].IsAccess[i].pos div 2].task + '",';
		  end;
		end
		else
		begin
		  if (Players[userindex].IsAccess[i].uniID = RunProjects[PrjInd].uniID) then
		  begin
			Result := Result + '"' + Projects[RunProjects[PrjInd].parentInd].map.RHs[Players[userindex].IsAccess[i].pos div 2].task + '",';
		  end;
		end;
	// Result := Result + '"'+Projects[RunProjects[PrjInd].parentInd].map.ReadString('RV:' + (Players[i].IsAccess[j].pos div 2).ToString, 'dor', '') + ''';';
	// Result := Result + '"' + Projects[RunProjects[PrjInd].parentInd].tasks[i] + '":' + Players[userindex].IsAccess[RunProjects[PrjInd].parentInd][i].ToInteger.ToString + ',';
	if Result[length(Result)] = ',' then
	  Delete(Result, length(Result), 1);
	Result := Result + ']';
  end
  else if (s = 'get_prog_list') and (Players[userindex].isAdmin) then
  begin
	Result := '[';
	for i := 0 to High(Projects) do
	begin
	  Result := Result + '{';
	  Result := Result + '"folder":"' + MyTXT2INI(StringReplace(Projects[i].folder, '\', '/', [rfReplaceAll])) + '",';
	  Result := Result + '"name":"' + MyTXT2INI(Projects[i].name) + '",';
	  Result := Result + '"tasks_info":[';
	  for j := 0 to High(Projects[i].tasks_info) do
	  begin
		Result := Result + '{';
		Result := Result + '"DefaultProgram":"' + MyTXT2INI(Projects[i].tasks_info[j].DefaultProgram) + '",';
		Result := Result + '"folder":"' + MyTXT2INI(Projects[i].tasks_info[j].folder) + '",';
		Result := Result + '"solution":"' + MyTXT2INI(Projects[i].tasks_info[j].solution) + '",';
		Result := Result + '"name":"' + MyTXT2INI(Projects[i].tasks_info[j].name) + '",';
		Result := Result + '"tests":[';
		for k := 0 to High(Projects[i].tasks_info[j].test) do
		begin
		  if FileExists(LoadDirectory + '\' + Projects[i].folder + StringReplace(Projects[i].tasks_info[j].test[k], '\/', '\', [rfReplaceAll])) then
			Result := Result + '"' + MyTXT2INI(LoadFileToStr(LoadDirectory + '\' + Projects[i].folder + StringReplace(Projects[i].tasks_info[j].test[k], '\/', '\', [rfReplaceAll]))) + '",';
		end;

		if Result[length(Result)] = ',' then
		  Delete(Result, length(Result), 1);
		Result := Result + ']},';
	  end;
	  if Result[length(Result)] = ',' then
		Delete(Result, length(Result), 1);
	  Result := Result + ']},';
	end;
	// Result := Result + '"'+Projects[RunProjects[PrjInd].parentInd].map.ReadString('RV:' + (Players[i].IsAccess[j].pos div 2).ToString, 'dor', '') + ''';';
	// Result := Result + '"' + Projects[RunProjects[PrjInd].parentInd].tasks[i] + '":' + Players[userindex].IsAccess[RunProjects[PrjInd].parentInd][i].ToInteger.ToString + ',';
	if Result[length(Result)] = ',' then
	  Delete(Result, length(Result), 1);
	Result := Result + ']';
  end
  else if (s = 'get_programs') and (Players[userindex].isAdmin) then
  begin
	Result := '{"time":"' + IntToStr(DateTimeToUnix(Now(), false)) + '","programs":[';
	for i := 0 to High(Players) do
	  for j := 0 to High(Players[i].programs) do
	  begin
		Result := Result + '{';
		Result := Result + '"Login":"' + MyTXT2INI(Players[i].login) + '",';
		Result := Result + '"Name":"' + MyTXT2INI(Players[i].name + Iif(Players[i].ip <> '', ' [' + Players[i].ip + ']')) + '",';
		Result := Result + '"programm":"' + MyTXT2INI(Players[i].programs[j].programm) + '",';
		Result := Result + '"exit_data":"' + MyTXT2INI(Players[i].programs[j].exit_data) + '",';
		Result := Result + '"res":"' + Players[i].programs[j].res + '",';
		Result := Result + '"task":"' + Players[i].programs[j].task.ToString + '",';
		Result := Result + '"date":"' + Players[i].programs[j].date.ToString + '",';
		for k := 0 to High(RunProjects) do
		  if RunProjects[k].uniID = Players[i].programs[j].uniID then
			if (Players[i].programs[j].task >= 0) and (Players[i].programs[j].task <= High(Projects[RunProjects[k].parentInd].tasks_info)) then
			begin
			  Result := Result + '"task_name":"' + MyTXT2INI(Projects[RunProjects[k].parentInd].tasks[Players[i].programs[j].task]) + '",';
			  Result := Result + '"proj_name":"' + MyTXT2INI(Projects[RunProjects[k].parentInd].name) + '",';
			  break;
			end;

		Result := Result + '"uniID":"' + Players[i].programs[j].uniID + '"';
		Result := Result + '},';
	  end;
	// Result := Result + '"'+Projects[RunProjects[PrjInd].parentInd].map.ReadString('RV:' + (Players[i].IsAccess[j].pos div 2).ToString, 'dor', '') + ''';';
	// Result := Result + '"' + Projects[RunProjects[PrjInd].parentInd].tasks[i] + '":' + Players[userindex].IsAccess[RunProjects[PrjInd].parentInd][i].ToInteger.ToString + ',';
	if Result[length(Result)] = ',' then
	  Delete(Result, length(Result), 1);
	Result := Result + ']}';
  end
  else if (s = 'get_dors') and (PrjInd >= 0) then
  begin
	Result := '{';
	for i := 0 to High(Projects[RunProjects[PrjInd].parentInd].map.RVs) do
	  if (Projects[RunProjects[PrjInd].parentInd].map.RVs[i].task <> '') and (Projects[RunProjects[PrjInd].parentInd].map.RVs[i].task <> 'open') then
	  begin
		Result := Result + '"' + Projects[RunProjects[PrjInd].parentInd].map.RVs[i].pos[0].ToString + ';' +
		  ((Projects[RunProjects[PrjInd].parentInd].map.RVs[i].pos[1] + Projects[RunProjects[PrjInd].parentInd].map.RVs[i].pos[2]) div 2).ToString + '":"' + Projects[RunProjects[PrjInd].parentInd]
		  .map.RVs[i].task + '",';
	  end;
	for i := 0 to High(Projects[RunProjects[PrjInd].parentInd].map.RHs) do
	  if (Projects[RunProjects[PrjInd].parentInd].map.RHs[i].task <> '') and (Projects[RunProjects[PrjInd].parentInd].map.RHs[i].task <> 'open') then
	  begin
		Result := Result + '"' + ((Projects[RunProjects[PrjInd].parentInd].map.RHs[i].pos[1] + Projects[RunProjects[PrjInd].parentInd].map.RHs[i].pos[2]) div 2).ToString + ';' +
		  Projects[RunProjects[PrjInd].parentInd].map.RHs[i].pos[0].ToString + '":"' + Projects[RunProjects[PrjInd].parentInd].map.RHs[i].task + '",';
	  end;
	// Result := Result + '"'+Projects[RunProjects[PrjInd].parentInd].map.ReadString('RV:' + (Players[i].IsAccess[j].pos div 2).ToString, 'dor', '') + ''';';
	// Result := Result + '"' + Projects[RunProjects[PrjInd].parentInd].tasks[i] + '":' + Players[userindex].IsAccess[RunProjects[PrjInd].parentInd][i].ToInteger.ToString + ',';
	if Result[length(Result)] = ',' then
	  Delete(Result, length(Result), 1);
	Result := Result + '}';
  end
  else if (s = 'gettab') and (PrjInd >= 0) then
  begin
	Result := '[' + #13#10;
	if (Players[userindex].isAdmin) then
	  for i := 0 to High(Projects[RunProjects[PrjInd].parentInd].tasks_info) do
	  begin
		Result := Result + '	{' + #13#10;
		Result := Result + '		"DefaultProgram": "' + str2json(Projects[RunProjects[PrjInd].parentInd].tasks_info[i].DefaultProgram) + '",' + #13#10;
		Result := Result + '		"name": "' + Projects[RunProjects[PrjInd].parentInd].tasks_info[i].name + '",' + #13#10;
		Result := Result + '		"tab": [';
		for j := 0 to High(Projects[RunProjects[PrjInd].parentInd].tasks_info[i].tab) do
		begin
		  Result := Result + '{';
		  Result := Result + '				"name": "' + Projects[RunProjects[PrjInd].parentInd].tasks_info[i].tab[j]._name + '",' + #13#10;
		  if Projects[RunProjects[PrjInd].parentInd].tasks_info[i].tab[j]._type = 'text' then
			Result := Result + '				"text": "' + str2json(Projects[RunProjects[PrjInd].parentInd].tasks_info[i].tab[j]._text) + '",' + #13#10
		  else if Projects[RunProjects[PrjInd].parentInd].tasks_info[i].tab[j]._type = 'fil' then
			Result := Result + '				"url": "' + Projects[RunProjects[PrjInd].parentInd].tasks_info[i].tab[j]._text + '",' + #13#10
		  else if Projects[RunProjects[PrjInd].parentInd].tasks_info[i].tab[j]._type = 'site' then
			Result := Result + '				"url": "' + Projects[RunProjects[PrjInd].parentInd].tasks_info[i].tab[j]._text + '",' + #13#10
		  else if Projects[RunProjects[PrjInd].parentInd].tasks_info[i].tab[j]._type = 'load' then
		  else
			writeln('er9234');
		  Result := Result + '				"type": "' + Projects[RunProjects[PrjInd].parentInd].tasks_info[i].tab[j]._type + '"' + #13#10;
		  Result := Result + '			},';
		end;
		if Result[length(Result)] = ',' then
		  Delete(Result, length(Result), 1);
		Result := Result + '],' + #13#10;
		Result := Result + '		"tests": [';
		for j := 0 to High(Projects[RunProjects[PrjInd].parentInd].tasks_info[i].test) do
		  Result := Result + '"' + Projects[RunProjects[PrjInd].parentInd].tasks_info[i].test[j] + '",';
		if Result[length(Result)] = ',' then
		  Delete(Result, length(Result), 1);
		Result := Result + ']' + #13#10;
		Result := Result + '	},';

	  end;
	if (not Players[userindex].isAdmin) then
	  for k := 0 to High(Players[userindex].IsAccess) do
		if (Players[userindex].IsAccess[k].uniID = RunProjects[PrjInd].uniID) then
		begin
		  if (Players[userindex].IsAccess[k].pos mod 2 = 0) then
		  begin
			s2 := Projects[RunProjects[PrjInd].parentInd].map.RVs[Players[userindex].IsAccess[k].pos div 2].task;
		  end
		  else
		  begin
			s2 := Projects[RunProjects[PrjInd].parentInd].map.RHs[Players[userindex].IsAccess[k].pos div 2].task;
		  end;
		  for i := 0 to High(Projects[RunProjects[PrjInd].parentInd].tasks_info) do
			if Projects[RunProjects[PrjInd].parentInd].tasks_info[i].name = s2 then
			begin
			  Result := Result + '	{' + #13#10;
			  Result := Result + '		"DefaultProgram": "' + str2json(Projects[RunProjects[PrjInd].parentInd].tasks_info[i].DefaultProgram) + '",' + #13#10;
			  Result := Result + '		"name": "' + Projects[RunProjects[PrjInd].parentInd].tasks_info[i].name + '",' + #13#10;
			  Result := Result + '		"tab": [';
			  for j := 0 to High(Projects[RunProjects[PrjInd].parentInd].tasks_info[i].tab) do
			  begin
				Result := Result + '{';
				Result := Result + '				"name": "' + Projects[RunProjects[PrjInd].parentInd].tasks_info[i].tab[j]._name + '",' + #13#10;
				if Projects[RunProjects[PrjInd].parentInd].tasks_info[i].tab[j]._type = 'text' then
				  Result := Result + '				"text": "' + str2json(Projects[RunProjects[PrjInd].parentInd].tasks_info[i].tab[j]._text) + '",' + #13#10
				else if Projects[RunProjects[PrjInd].parentInd].tasks_info[i].tab[j]._type = 'fil' then
				  Result := Result + '				"url": "' + Projects[RunProjects[PrjInd].parentInd].tasks_info[i].tab[j]._text + '",' + #13#10
				else if Projects[RunProjects[PrjInd].parentInd].tasks_info[i].tab[j]._type = 'site' then
				  Result := Result + '				"url": "' + Projects[RunProjects[PrjInd].parentInd].tasks_info[i].tab[j]._text + '",' + #13#10
				else if Projects[RunProjects[PrjInd].parentInd].tasks_info[i].tab[j]._type = 'load' then
				else
				  writeln('er9235');
				Result := Result + '				"type": "' + Projects[RunProjects[PrjInd].parentInd].tasks_info[i].tab[j]._type + '"' + #13#10;
				Result := Result + '			},';
			  end;
			  if Result[length(Result)] = ',' then
				Delete(Result, length(Result), 1);
			  Result := Result + ']' + #13#10; // ,
			  // Result := Result + '		"tests": [';
			  // for j := 0 to High(Projects[RunProjects[PrjInd].parentInd].tasks_info[i].test) do
			  // Result := Result + '"' + Projects[RunProjects[PrjInd].parentInd].tasks_info[i].test[j] + '",';
			  // if Result[length(Result)] = ',' then
			  // Delete(Result, length(Result), 1);
			  // Result := Result + ']' + #13#10;
			  Result := Result + '	},';
			  break;
			end;
		end;

	if Result[length(Result)] = ',' then
	  Delete(Result, length(Result), 1);
	Result := Result + ']';
  end
  else if (s = 'getpos') and (PrjInd >= 0) then
  begin
	Result := '{' + #13#10 + '  "count": ' + length(Players).ToString + ',' + #13#10;
	for i := Low(Players) to High(Players) - 1 do
	begin
	  Result := Result + '  "Player:' + i.ToString + '": [' + #13#10;
	  Result := Result + '    {' + #13#10;
	  Result := Result + '      "Name": "' + Players[i].login + '",' + #13#10;
	  f := 0;
	  for j := 0 to High(Players[i].pos) do
		if Players[i].pos[j].uniID = RunProjects[PrjInd].uniID then
		begin
		  Result := Result + '      "posx": ' + Players[i].pos[j].posx.ToString + ',' + #13#10;
		  Result := Result + '      "posy": ' + Players[i].pos[j].posy.ToString + ',' + #13#10;
		  f := 1;
		  break;
		end;
	  if (f = 0) and (userindex = i) then
	  begin

		if RunProjects[PrjInd].time_start > DateTimeToUnix(Now(), false) then
		  f := 0
		else if RunProjects[PrjInd].group = '' then
		  f := 1
		else if Players[i].isAdmin then
		  f := 1
		else
		begin
		  k := 0;
		  for j := 0 to High(RunProjects[PrjInd].group.Split([','])) do
			if trim(Players[i].group) = trim(RunProjects[PrjInd].group.Split([','])[j]) then
			begin
			  k := 1;
			  break;
			end;
		  if k = 0 then
			f := 0
		  else
			f := 1
		end;
		if f = 1 then
		begin
		  SetLength(Players[i].pos, length(Players[i].pos) + 1);
		  Players[i].pos[High(Players[i].pos)] := Aarraofstrintint.Create();
		  Players[i].pos[High(Players[i].pos)].uniID := RunProjects[PrjInd].uniID;
		  Players[i].pos[High(Players[i].pos)].posx := 0;
		  Players[i].pos[High(Players[i].pos)].posy := 0;
		  Result := Result + '      "posx": 0,' + #13#10;
		  Result := Result + '      "posy": 0,' + #13#10;
		  f := 1;
		end;
	  end;
	  Result := Result + '      "personage1": ' + Players[i].Pers[0].ToString + ',' + #13#10;
	  Result := Result + '      "personage2": ' + Players[i].Pers[1].ToString + ',' + #13#10;
	  Result := Result + '      "personage3": ' + Players[i].Pers[2].ToString + ',' + #13#10;
	  Result := Result + '      "personage4": ' + Players[i].Pers[3].ToString + ',' + #13#10;
	  Result := Result + '      "personage5": ' + Players[i].Pers[4].ToString + ',' + #13#10;
	  Result := Result + '      "personage6": ' + Players[i].Pers[5].ToString + ',' + #13#10;
	  if Players[i].isAdmin then
		Result := Result + '      "isAdmin": "true"' + #13#10
	  else
		Result := Result + '      "isAdmin": "false"' + #13#10;
	  Result := Result + '    }' + #13#10;
	  Result := Result + '  ],' + #13#10;

	end;
	i := High(Players);
	Result := Result + '  "Player:' + i.ToString + '": [' + #13#10;
	Result := Result + '    {' + #13#10;
	Result := Result + '      "Name": "' + Players[i].login + '",' + #13#10;
	f := 0;
	for j := 0 to High(Players[i].pos) do
	  if Players[i].pos[j].uniID = RunProjects[PrjInd].uniID then
	  begin
		Result := Result + '      "posx": ' + Players[i].pos[j].posx.ToString + ',' + #13#10;
		Result := Result + '      "posy": ' + Players[i].pos[j].posy.ToString + ',' + #13#10;
		f := 1;
		break;
	  end;
	if (f = 0) and (userindex = i) then
	begin

	  if RunProjects[PrjInd].time_start > DateTimeToUnix(Now(), false) then
		f := 0
	  else if RunProjects[PrjInd].group = '' then
		f := 1
	  else if Players[i].isAdmin then
		f := 1
	  else
	  begin
		k := 0;
		for j := 0 to High(RunProjects[PrjInd].group.Split([','])) do
		  if trim(Players[i].group) = trim(RunProjects[PrjInd].group.Split([','])[j]) then
		  begin
			k := 1;
			break;
		  end;
		if k = 0 then
		  f := 0
		else
		  f := 1
	  end;
	  if f = 1 then
	  begin
		SetLength(Players[i].pos, length(Players[i].pos) + 1);
		Players[i].pos[High(Players[i].pos)] := Aarraofstrintint.Create();
		Players[i].pos[High(Players[i].pos)].uniID := RunProjects[PrjInd].uniID;
		Players[i].pos[High(Players[i].pos)].posx := 0;
		Players[i].pos[High(Players[i].pos)].posy := 0;
		Result := Result + '      "posx": 0,' + #13#10;
		Result := Result + '      "posy": 0,' + #13#10;
		f := 1;
	  end;
	end;
	Result := Result + '      "personage1": ' + Players[i].Pers[0].ToString + ',' + #13#10;
	Result := Result + '      "personage2": ' + Players[i].Pers[1].ToString + ',' + #13#10;
	Result := Result + '      "personage3": ' + Players[i].Pers[2].ToString + ',' + #13#10;
	Result := Result + '      "personage4": ' + Players[i].Pers[3].ToString + ',' + #13#10;
	Result := Result + '      "personage5": ' + Players[i].Pers[4].ToString + ',' + #13#10;
	Result := Result + '      "personage6": ' + Players[i].Pers[5].ToString + ',' + #13#10;
	if Players[i].isAdmin then
	  Result := Result + '      "isAdmin": "true"' + #13#10
	else
	  Result := Result + '      "isAdmin": "false"' + #13#10;
	Result := Result + '    }' + #13#10;
	Result := Result + '  ]' + #13#10;
	Result := Result + '}';
  end
  else if (length(s.Split(['EditPersonage'])) > 1) and (length(s.Split(['EditPersonage'])[1].Split(['_'])) > 5) then
  begin
	Players[userindex].Pers[0] := s.Split(['EditPersonage'])[1].Split(['_'])[0].ToInteger;
	Players[userindex].Pers[1] := s.Split(['EditPersonage'])[1].Split(['_'])[1].ToInteger;
	Players[userindex].Pers[2] := s.Split(['EditPersonage'])[1].Split(['_'])[2].ToInteger;
	Players[userindex].Pers[3] := s.Split(['EditPersonage'])[1].Split(['_'])[3].ToInteger;
	Players[userindex].Pers[4] := s.Split(['EditPersonage'])[1].Split(['_'])[4].ToInteger;
	Players[userindex].Pers[5] := s.Split(['EditPersonage'])[1].Split(['_'])[5].ToInteger;
	Result := 'OK';
  end
  else if (s = '_server_list_') then
  begin
	Result := 'name;access;start_time;plus_end;server_uniID;' + #13#10;
	for i := 0 to High(RunProjects) do
	begin
	  if RunProjects[i].time_start > DateTimeToUnix(Now(), false) then
		Result := Result + RunProjects[i].visib_name + ';NOOK;' + IntToStr(DateTimeToUnix(Now(), false) - RunProjects[i].time_start) + ';' + (RunProjects[i].time_end - RunProjects[i].time_start)
		  .ToString + ';' + RunProjects[i].uniID + ';' + #13#10
	  else if RunProjects[i].group = '' then
		Result := Result + RunProjects[i].visib_name + ';OK;' + IntToStr(DateTimeToUnix(Now(), false) - RunProjects[i].time_start) + ';' + (RunProjects[i].time_end - RunProjects[i].time_start)
		  .ToString + ';' + RunProjects[i].uniID + ';' + #13#10
	  else if Players[userindex].isAdmin then
		Result := Result + RunProjects[i].visib_name + ';OK;' + IntToStr(DateTimeToUnix(Now(), false) - RunProjects[i].time_start) + ';' + (RunProjects[i].time_end - RunProjects[i].time_start)
		  .ToString + ';' + RunProjects[i].uniID + ';' + #13#10
	  else
	  begin
		k := 0;
		for j := 0 to High(RunProjects[i].group.Split([','])) do
		  if trim(Players[userindex].group) = trim(RunProjects[i].group.Split([','])[j]) then
		  begin
			k := 1;
			break;
		  end;
		if k = 0 then
		  Result := Result + RunProjects[i].visib_name + ';NOOK;' + IntToStr(DateTimeToUnix(Now(), false) - RunProjects[i].time_start) + ';' + (RunProjects[i].time_end - RunProjects[i].time_start)
			.ToString + ';' + RunProjects[i].uniID + ';' + #13#10
		else
		  Result := Result + RunProjects[i].visib_name + ';OK;' + IntToStr(DateTimeToUnix(Now(), false) - RunProjects[i].time_start) + ';' + (RunProjects[i].time_end - RunProjects[i].time_start)
			.ToString + ';' + RunProjects[i].uniID + ';' + #13#10
	  end;
	end;
  end
  else if (s = 'get_time') and (PrjInd >= 0) then
  begin
	if (Now() < unixtodatetime(RunProjects[PrjInd].time_end, false)) then
	  Result := 'time: ' + DateTimeToUnix(Now(), false).ToString + #13#10 + 'delta: ' + MilliSecondsBetween(Now(), unixtodatetime(RunProjects[PrjInd].time_end, false)).ToString
	else
	  Result := 'time: ' + DateTimeToUnix(Now(), false).ToString + #13#10 + 'delta: ' + (-MilliSecondsBetween(Now(), unixtodatetime(RunProjects[PrjInd].time_end, false))).ToString
  end
  else if (s = 'get_table') and (PrjInd >= 0) then
  begin
	// string_freeze:string;
	// time_freeze:int64;
	if Players[userindex].isAdmin then
	  if RunProjects[PrjInd].time_freeze < DateTimeToUnix(Now(), false) then
	  begin
		if RunProjects[PrjInd].string_freeze = '' then
		  RunProjects[PrjInd].string_freeze := GetSortPlayers(false, PrjInd);
		Result := 'F' + GetSortPlayers(Players[userindex].isAdmin, PrjInd)
	  end
	  else
	  begin
		Result := 'N' + GetSortPlayers(Players[userindex].isAdmin, PrjInd);
		RunProjects[PrjInd].string_freeze := '';
	  end;

	if not Players[userindex].isAdmin then
	  if RunProjects[PrjInd].time_freeze < DateTimeToUnix(Now(), false) then
	  begin
		if RunProjects[PrjInd].string_freeze = '' then
		  RunProjects[PrjInd].string_freeze := GetSortPlayers(false, PrjInd);
		Result := 'F' + RunProjects[PrjInd].string_freeze;
	  end
	  else
	  begin
		Result := 'N' + GetSortPlayers(Players[userindex].isAdmin, PrjInd);
		RunProjects[PrjInd].string_freeze := '';
	  end;

  end
  else if (length(s.Split(['Get_my_programs'])) > 1) and (PrjInd >= 0) then
  begin
	Result := '[';
	j := 0;
	for i := High(Players[userindex].programs) downto Low(Players[userindex].programs) do
	  if Players[userindex].programs[i].uniID = RunProjects[PrjInd].uniID then
		if Projects[RunProjects[PrjInd].parentInd].tasks[Players[userindex].programs[i].task] = TIdURI.URLDecode(StringReplace(s.Split(['Get_my_programs'])[1], '+', ' ', [rfReplaceAll, rfIgnoreCase]))
		then
		begin
		  inc(j);
		  if j > 50 then
			break;
		  Result := Result + '[' + i.ToString() + ',"' + Players[userindex].programs[i].res + '","' + Players[userindex].programs[i].date.ToString + '"]';
		  Result := Result + ',';

		end;
	if Result[length(Result)] = ',' then
	  Delete(Result, length(Result), 1);
	Result := Result + ']';

  end
  else if (length(s.Split(['Get_my_program'])) > 1) and (PrjInd >= 0) then
  begin
	i := StrToInt(s.Split(['Get_my_program'])[1]);
	Result := 'Error';
	if (i < 0) or (i > High(Players[userindex].programs)) then
	  exit;
	Result := 'Номер: ' + i.ToString() + #13#10;
	Result := Result + 'Ответ тестирующей системы: ' + Players[userindex].programs[i].res + #13#10;
	Result := Result + 'Дата отправки: ' + DateToFileName(unixtodatetime(Players[userindex].programs[i].date, false)) + #13#10;
	Result := Result + #13#10;

	Result := Result + Players[userindex].programs[i].programm;
  end
  else if (Players[userindex].isAdmin) then
  begin
	if (s = '_my_server_list_') then
	begin
	  Result := 'name;access;start_time;plus_end;server_uniID;' + #13#10;
	  for i := 0 to High(RunProjects) do
	  begin
		k := 0;
		for j := 0 to High(RunProjects[i].group.Split([','])) do
		  if 'gr_' + trim(Players[userindex].login) = trim(RunProjects[i].group.Split([','])[j]) then
		  begin
			k := 1;
			break;
		  end;
		if '' = trim(RunProjects[i].group) then
		begin
		  k := 1;
		end;

		if k = 0 then
		  continue;

		if RunProjects[i].time_start > DateTimeToUnix(Now(), false) then
		  Result := Result + RunProjects[i].visib_name + ';NOOK;' + RunProjects[i].time_start.ToString + ';' + (RunProjects[i].time_end - RunProjects[i].time_freeze).ToString + ';' +
			(RunProjects[i].time_end - RunProjects[i].time_start).ToString + ';' + RunProjects[i].uniID + ';' + #13#10
		else if RunProjects[i].time_end < DateTimeToUnix(Now(), false) then
		  Result := Result + RunProjects[i].visib_name + ';NOOK;' + RunProjects[i].time_start.ToString + ';' + (RunProjects[i].time_end - RunProjects[i].time_freeze).ToString + ';' +
			(RunProjects[i].time_end - RunProjects[i].time_start).ToString + ';' + RunProjects[i].uniID + ';' + #13#10
		else if RunProjects[i].group = '' then
		  Result := Result + RunProjects[i].visib_name + ';ALL;' + RunProjects[i].time_start.ToString + ';' + (RunProjects[i].time_end - RunProjects[i].time_freeze).ToString + ';' +
			(RunProjects[i].time_end - RunProjects[i].time_start).ToString + ';' + RunProjects[i].uniID + ';' + #13#10
		else
		begin
		  k := 0;
		  for j := 0 to High(RunProjects[i].group.Split([','])) do
			if '' = trim(RunProjects[i].group.Split([','])[j]) then
			begin
			  k := 1;
			  break;
			end;
		  if k = 1 then
		  begin
			Result := Result + RunProjects[i].visib_name + ';ALL;' + RunProjects[i].time_start.ToString + ';' + (RunProjects[i].time_end - RunProjects[i].time_freeze).ToString + ';' +
			  (RunProjects[i].time_end - RunProjects[i].time_start).ToString + ';' + RunProjects[i].uniID + ';' + #13#10;
			continue;
		  end;
		  k := 0;
		  for j := 0 to High(RunProjects[i].group.Split([','])) do
			if 'gr_player_' + trim(Players[userindex].login) = trim(RunProjects[i].group.Split([','])[j]) then
			begin
			  k := 1;
			  break;
			end;
		  if k = 0 then
			Result := Result + RunProjects[i].visib_name + ';ONLY_YOU;' + RunProjects[i].time_start.ToString + ';' + (RunProjects[i].time_end - RunProjects[i].time_freeze).ToString + ';' +
			  (RunProjects[i].time_end - RunProjects[i].time_start).ToString + ';' + RunProjects[i].uniID + ';' + #13#10
		  else
			Result := Result + RunProjects[i].visib_name + ';YOU_AND_YOUR_GRUOP;' + RunProjects[i].time_start.ToString + ';' + (RunProjects[i].time_end - RunProjects[i].time_freeze).ToString + ';' +
			  (RunProjects[i].time_end - RunProjects[i].time_start).ToString + ';' + RunProjects[i].uniID + ';' + #13#10;
		end;
	  end;
	end
	else if (s = '_proj_list_') then
	begin
	  Result := 'folder;name;tasks' + #13#10;
	  for i := 0 to High(Projects) do
	  begin
		Result := Result + Projects[i].folder + ';_s_p_l_i_t_;' + Projects[i].name + ';_s_p_l_i_t_;';
		for j := 0 to High(Projects[i].tasks) do
		  Result := Result + Projects[i].tasks[j] + ';_s_p_l_i_t_;';
		Result := Result + #13#10;
	  end;
	end
	else if (length(s.Split(['create_proj_'])) = 2) then
	begin
	  // create_proj_(proj parent)_(visib name)_(time_start)_(time_freeze)_(time_end)_(group)_(uniID)_

	  if (length(s.Split(['_'])) <> 10) then
		Result := 'Bad request(' + length(s.Split(['_'])).ToString + ')'
	  else if s.Split(['_'])[2].ToInteger.ToString <> s.Split(['_'])[2] then // proj parent
		Result := 'Bad request2'
	  else if (length(TIdURI.URLDecode(StringReplace(s.Split(['_'])[3], '+', ' ', [rfReplaceAll, rfIgnoreCase]))) < 3) then // visib name
		Result := 'Bad request3'
	  else if s.Split(['_'])[4].ToInt64.ToString <> s.Split(['_'])[4] then // time start
		Result := 'Bad request4'
	  else if s.Split(['_'])[5].ToInt64.ToString <> s.Split(['_'])[5] then // time freeze
		Result := 'Bad request5'
	  else if s.Split(['_'])[6].ToInt64.ToString <> s.Split(['_'])[6] then // time end
		Result := 'Bad request6'
	  else if not((s.Split(['_'])[7] = 'All') or (s.Split(['_'])[7] = 'Gr') or (s.Split(['_'])[7] = 'OnlyYou')) then // group
		Result := 'Bad request7'
	  else if (length(s.Split(['_'])[8]) <> 10) then
		Result := 'Bad request8'
	  else
	  begin
		for i := 0 to High(RunProjects) do
		  if RunProjects[i].uniID = s.Split(['_'])[8] then
		  begin
			Result := 'uniID занят';
			exit;
		  end;
		SetLength(RunProjects, length(RunProjects) + 1);
		RunProjects[High(RunProjects)] := TRunProject.Create;
		RunProjects[High(RunProjects)].parentInd := s.Split(['_'])[2].ToInteger;
		RunProjects[High(RunProjects)].uniID := s.Split(['_'])[8];
		RunProjects[High(RunProjects)].visib_name := TIdURI.URLDecode(StringReplace(s.Split(['_'])[3], '+', ' ', [rfReplaceAll, rfIgnoreCase]));
		RunProjects[High(RunProjects)].string_freeze := '';
		RunProjects[High(RunProjects)].time_start := s.Split(['_'])[4].ToInt64 div 1000;
		RunProjects[High(RunProjects)].time_freeze := s.Split(['_'])[5].ToInt64 div 1000;
		RunProjects[High(RunProjects)].time_end := s.Split(['_'])[6].ToInt64 div 1000;
		if (s.Split(['_'])[7] = 'All') then
		  RunProjects[High(RunProjects)].group := '';
		if (s.Split(['_'])[7] = 'Gr') then
		  RunProjects[High(RunProjects)].group := 'gr_player_' + trim(Players[userindex].login) + ',gr_' + trim(Players[userindex].login);
		if (s.Split(['_'])[7] = 'OnlyYou') then
		  RunProjects[High(RunProjects)].group := 'gr_' + trim(Players[userindex].login);
		Result := 'OK';
	  end;

	end
	else if (length(s.Split(['del_proj_'])) = 2) then
	begin
	  if (length(s.Split(['_'])) <> 4) then
		Result := 'Bad request'
	  else if (length(s.Split(['_'])[2]) <> 10) then
		Result := 'Bad request2'
	  else
	  begin
		Result := 'NOTFOUND';
		for i := 0 to High(RunProjects) do
		  if RunProjects[i].uniID = s.Split(['_'])[2] then
		  begin
			RunProjects[i].Free;
			RunProjects[i] := RunProjects[High(RunProjects)];
			SetLength(RunProjects, length(RunProjects) - 1);
			Result := 'OK';
			exit;
		  end;
	  end;
	end
	else if (length(s.Split(['_get_top_proj_'])) = 2) then
	begin
	  if (length(s.Split(['_'])) <> 6) then
		Result := 'Bad request'
	  else if (length(s.Split(['_'])[4]) <> 10) then
		Result := 'Bad request2'
	  else
	  begin
		Result := 'NOTFOUND';
		for i := 0 to High(RunProjects) do
		  if RunProjects[i].uniID = s.Split(['_'])[4] then
		  begin
			Result := GetSortPlayers(true, i);
			exit;
		  end;
	  end;
	end
	else if (length(s.Split(['_get_stat_players_'])) = 2) then
	begin
	  j := 0;
	  k := 0;
	  for i := 0 to High(Players) do
	  begin
		if ((trim(Players[i].group) = '') and (not Players[i].isAdmin)) then
		begin
		  inc(j);
		end;
		if trim(Players[i].group) = 'gr_player_' + trim(Players[userindex].login) then
		begin
		  inc(k);
		end;
	  end;
	  Result := k.ToString + #13#10 + j.ToString + #13#10 + length(Players).ToString + #13#10;
	end
	else if (length(s.Split(['_get_players_no_group_'])) = 2) then
	begin
	  Result := 'login;name;' + #13#10;
	  for i := 0 to High(Players) do
		if ((trim(Players[i].group) = '') and (not Players[i].isAdmin)) then
		  Result := Result + Players[i].login + ';' + Players[i].name + Iif(Players[i].ip <> '', ' [' + Players[i].ip + ']') + ';' + #13#10;
	end
	else if (length(s.Split(['_get_players_in_group_'])) = 2) then
	begin
	  Result := 'login;name;' + #13#10;
	  for i := 0 to High(Players) do
		if trim(Players[i].group) = 'gr_player_' + trim(Players[userindex].login) then
		  Result := Result + Players[i].login + ';' + Players[i].name + Iif(Players[i].ip <> '', ' [' + Players[i].ip + ']') + ';' + #13#10;
	end
	else if (length(s.Split(['_player_add_group_'])) = 2) then
	begin
	  if (length(s.Split(['_'])) <> 6) then
		Result := 'Login have _'
	  else if (GetIndex(s.Split(['_'])[4]) < 0) then
		Result := 'Login not found'
	  else
	  begin
		i := GetIndex(s.Split(['_'])[4]);
		if ((trim(Players[i].group) = '') and (not Players[i].isAdmin)) then
		begin
		  Players[i].group := 'gr_player_' + trim(Players[userindex].login);
		  Result := 'OK';
		end
		else
		  Result := 'NOOK';
	  end;
	end
	else if (length(s.Split(['_player_del_group_'])) = 2) then
	begin
	  if (length(s.Split(['_'])) <> 6) then
		Result := 'Bad request'
	  else if (GetIndex(s.Split(['_'])[4]) < 0) then
		Result := 'Bad request2'
	  else
	  begin
		i := GetIndex(s.Split(['_'])[4]);
		if trim(Players[i].group) = 'gr_player_' + trim(Players[userindex].login) then
		begin
		  Players[i].group := '';
		  Result := 'OK';
		end
		else
		  Result := 'NOOK';
	  end;
	end
  end;
end;
	
*/

(global || window).api_request_map = api_request_map;